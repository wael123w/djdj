<?php

namespace App\Services;

use App\Models\Referral;
use App\Models\User;
use App\Repositories\Contracts\UserRepositoryInterface;

class ReferralService
{
    private float $commissionRate = 0.05;

    public function __construct(private UserRepositoryInterface $userRepo) {}

    public function processReferral(User $newUser, ?string $referralCode): void
    {
        if (!$referralCode) return;
        $referrer = $this->userRepo->findByReferralCode($referralCode);
        if (!$referrer || $referrer->id === $newUser->id) return;

        Referral::create([
            'referrer_id' => $referrer->id,
            'referred_id' => $newUser->id,
            'status' => 'pending',
        ]);
        $newUser->update(['referred_by' => $referrer->id]);
    }

    public function awardCommission(Referral $referral, float $orderTotal): void
    {
        $commission = $orderTotal * $this->commissionRate;
        $referral->update([
            'commission' => $commission,
            'status' => 'paid',
        ]);
        $this->userRepo->updateBalance($referral->referrer, $commission);
    }

    public function getReferralStats(User $user): array
    {
        $referrals = Referral::where('referrer_id', $user->id);
        return [
            'total_referrals' => (clone $referrals)->count(),
            'pending' => (clone $referrals)->where('status', 'pending')->count(),
            'paid' => (clone $referrals)->where('status', 'paid')->count(),
            'total_commission' => (clone $referrals)->where('status', 'paid')->sum('commission'),
        ];
    }
}
