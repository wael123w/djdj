<?php

namespace App\Services;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\Product;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\Alfaore\AlfaoreApiService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class StatisticsService
{
    public function __construct(
        private OrderRepositoryInterface $orderRepo,
        private AlfaoreApiService $alfaoreApi,
    ) {}

    public function getDashboardStats(): array
    {
        return Cache::remember('admin.dashboard.stats', 300, function () {
            $today = $this->orderRepo->getTodayStats();
            $apiBalance = $this->getApiBalance();

            $topProducts = Product::select('products.*', DB::raw('SUM(order_items.quantity) as total_sold'))
                ->join('order_items', 'products.id', '=', 'order_items.product_id')
                ->join('orders', 'orders.id', '=', 'order_items.order_id')
                ->where('orders.status', OrderStatus::COMPLETED)
                ->groupBy('products.id')
                ->orderByDesc('total_sold')
                ->limit(5)
                ->get();

            $topCategories = DB::table('categories')
                ->select('categories.name_ar', 'categories.name_en', DB::raw('COUNT(orders.id) as orders_count'))
                ->join('products', 'categories.id', '=', 'products.category_id')
                ->join('order_items', 'products.id', '=', 'order_items.product_id')
                ->join('orders', 'orders.id', '=', 'order_items.order_id')
                ->where('orders.status', OrderStatus::COMPLETED)
                ->groupBy('categories.id')
                ->orderByDesc('orders_count')
                ->limit(5)
                ->get();

            return [
                'api_balance' => $apiBalance,
                'today_orders' => $today['total'],
                'today_successful' => $today['completed'],
                'today_pending' => $today['pending'],
                'today_cancelled' => $today['cancelled'],
                'today_revenue' => $today['revenue'],
                'today_profit' => $today['profit'],
                'total_orders' => Order::count(),
                'total_revenue' => Order::paid()->sum('total') ?? 0,
                'total_profit' => Order::paid()->sum('profit') ?? 0,
                'top_products' => $topProducts,
                'top_categories' => $topCategories,
            ];
        });
    }

    public function getApiBalance(): float
    {
        return Cache::remember('alfaore.balance', 300, function () {
            try {
                return $this->alfaoreApi->getBalance();
            } catch (\Exception $e) {
                return 0;
            }
        });
    }

    public function getSalesChart(string $period = '30days'): array
    {
        $days = match ($period) {
            '7days' => 7,
            '30days' => 30,
            '90days' => 90,
            default => 30,
        };

        $data = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = now()->subDays($i)->format('Y-m-d');
            $stats = Order::whereDate('created_at', $date)->paid();
            $data[] = [
                'date' => $date,
                'orders' => (clone $stats)->count(),
                'revenue' => (clone $stats)->sum('total') ?? 0,
                'profit' => (clone $stats)->sum('profit') ?? 0,
            ];
        }
        return $data;
    }
}
