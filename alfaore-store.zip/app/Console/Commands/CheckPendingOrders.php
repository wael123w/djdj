<?php

namespace App\Console\Commands;

use App\Jobs\CheckPendingOrdersJob;
use Illuminate\Console\Command;

class CheckPendingOrders extends Command
{
    protected $signature = 'alfaore:check-orders';
    protected $description = 'Check pending orders status from Alfaore API';

    public function handle(): void
    {
        $this->info('Checking pending orders...');
        CheckPendingOrdersJob::dispatchSync();
        $this->info('Check completed!');
    }
}
