<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\StatisticsService;

class DashboardController extends Controller
{
    public function __construct(private StatisticsService $statisticsService) {}

    public function index()
    {
        $stats = $this->statisticsService->getDashboardStats();
        $chartData = $this->statisticsService->getSalesChart('30days');

        return view('admin.dashboard.index', compact('stats', 'chartData'));
    }
}
