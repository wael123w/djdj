<?php

namespace App\Services\Alfaore;

use App\Models\AlfaoreSyncLog;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Support\Facades\Log;

class AlfaoreSyncService
{
    public function __construct(
        private AlfaoreApiService $api,
        private ProductRepositoryInterface $productRepo
    ) {}

    public function syncProducts(): AlfaoreSyncLog
    {
        $log = AlfaoreSyncLog::create([
            'type' => 'products',
            'status' => 'success',
            'started_at' => now(),
        ]);

        try {
            $products = $this->api->getProducts();
            $log->items_processed = count($products);
            $result = $this->productRepo->syncFromAlfaore($products);
            $log->items_created = $result['created'];
            $log->items_updated = $result['updated'];
            $log->finished_at = now();
            $log->save();
            Log::info('Alfaore sync completed', ['log_id' => $log->id, 'result' => $result]);
        } catch (\Exception $e) {
            $log->status = 'failed';
            $log->error_message = $e->getMessage();
            $log->finished_at = now();
            $log->save();
            Log::error('Alfaore sync failed', ['error' => $e->getMessage()]);
        }

        return $log;
    }

    public function syncContent(): AlfaoreSyncLog
    {
        $log = AlfaoreSyncLog::create([
            'type' => 'content',
            'status' => 'success',
            'started_at' => now(),
        ]);
        try {
            $content = $this->api->getContent();
            $log->items_processed = count($content);
            $log->details = ['content' => $content];
            $log->finished_at = now();
            $log->save();
        } catch (\Exception $e) {
            $log->status = 'failed';
            $log->error_message = $e->getMessage();
            $log->finished_at = now();
            $log->save();
        }
        return $log;
    }

    public function checkPendingOrders(): void
    {
        $pendingOrders = \App\Models\Order::whereIn('status', ['pending', 'wait', 'processing'])
            ->whereNotNull('alfaore_order_id')
            ->get();

        foreach ($pendingOrders as $order) {
            try {
                $response = $this->api->checkOrder($order->alfaore_order_id);
                $data = $response['data'][0] ?? null;
                if ($data) {
                    $order->update([
                        'status' => $data['status'],
                        'alfaore_response' => $response,
                    ]);
                    event(new \App\Events\OrderStatusUpdated($order, $order->status));
                }
            } catch (\Exception $e) {
                Log::error('Failed to check Alfaore order', [
                    'order_id' => $order->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
}
