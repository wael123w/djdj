<?php

namespace App\Services\Alfaore;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class AlfaoreApiService
{
    private string $baseUrl;
    private string $apiToken;
    private int $timeout;
    private int $retryTimes;
    private int $retrySleep;

    public function __construct()
    {
        $this->baseUrl = rtrim(config('alfaore.base_url'), '/') . '/';
        $this->apiToken = config('alfaore.api_token');
        $this->timeout = config('alfaore.timeout', 30);
        $this->retryTimes = config('alfaore.retry_times', 3);
        $this->retrySleep = config('alfaore.retry_sleep', 2);
    }

    private function client()
    {
        return Http::withHeaders([
            'api-token' => $this->apiToken,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->timeout($this->timeout);
    }

    private function request(string $method, string $endpoint, array $data = []): array
    {
        $url = $this->baseUrl . ltrim($endpoint, '/');
        $attempt = 0;

        while ($attempt < $this->retryTimes) {
            try {
                $response = $method === 'GET'
                    ? $this->client()->get($url, $data)
                    : $this->client()->{$method}($url, $data);

                if ($response->successful()) {
                    return $response->json() ?? [];
                }

                Log::warning('Alfaore API error', [
                    'endpoint' => $endpoint,
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);

                $attempt++;
                if ($attempt < $this->retryTimes) {
                    sleep($this->retrySleep * $attempt);
                }
            } catch (\Exception $e) {
                Log::error('Alfaore API exception', [
                    'endpoint' => $endpoint,
                    'error' => $e->getMessage(),
                ]);
                $attempt++;
                if ($attempt < $this->retryTimes) {
                    sleep($this->retrySleep * $attempt);
                }
            }
        }

        throw new \Exception("Alfaore API failed after {$this->retryTimes} attempts: {$endpoint}");
    }

    public function getProfile(): array { return $this->request('GET', 'profile'); }
    public function getProducts(): array { return $this->request('GET', 'products'); }
    public function getProductsByIds(array $ids): array { return $this->request('GET', 'products', ['ids' => implode(',', $ids)]); }
    public function getMinimalProducts(): array { return $this->request('GET', 'products/minimal'); }
    public function getContent(): array { return $this->request('GET', 'content'); }
    public function getCategoryContent(int $categoryId): array { return $this->request('GET', "content/{$categoryId}"); }

    public function createOrder(int $productId, int $quantity, array $params = []): array
    {
        $payload = [
            'product_id' => $productId,
            'qty' => $quantity,
            'order_uuid' => (string) Str::uuid(),
        ];
        foreach ($params as $key => $value) {
            $payload[$key] = $value;
        }
        return $this->request('POST', 'order', $payload);
    }

    public function checkOrder(string $orderId, bool $useUuid = false): array
    {
        $endpoint = "check/{$orderId}";
        if ($useUuid) { $endpoint .= '?uuid=1'; }
        return $this->request('GET', $endpoint);
    }

    public function getBalance(): float
    {
        $profile = $this->getProfile();
        return (float) ($profile['balance'] ?? 0);
    }
}
