<?php

namespace App\Console;

use App\Jobs\CheckPendingOrdersJob;
use App\Jobs\SyncAlfaoreProductsJob;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected function schedule(Schedule $schedule): void
    {
        $schedule->job(new SyncAlfaoreProductsJob())
            ->everyFiveMinutes()
            ->name('alfaore-sync-products');

        $schedule->job(new CheckPendingOrdersJob())
            ->everyTenMinutes()
            ->name('alfaore-check-orders');
    }

    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');
    }
}
