@extends('layouts.app')
@section('title', __('Admin Dashboard'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Admin Dashboard') }}</h2>
    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="card text-white bg-primary"><div class="card-body"><h5>{{ __('API Balance') }}</h5><h3>€{{ number_format($stats['api_balance'], 2) }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-success"><div class="card-body"><h5>{{ __('Today Revenue') }}</h5><h3>${{ number_format($stats['today_revenue'], 2) }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-info"><div class="card-body"><h5>{{ __('Today Orders') }}</h5><h3>{{ $stats['today_orders'] }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-warning"><div class="card-body"><h5>{{ __('Today Profit') }}</h5><h3>${{ number_format($stats['today_profit'], 2) }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-secondary"><div class="card-body"><h5>{{ __('Successful') }}</h5><h3>{{ $stats['today_successful'] }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-dark"><div class="card-body"><h5>{{ __('Pending') }}</h5><h3>{{ $stats['today_pending'] }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-danger"><div class="card-body"><h5>{{ __('Cancelled') }}</h5><h3>{{ $stats['today_cancelled'] }}</h3></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-primary"><div class="card-body"><h5>{{ __('Total Revenue') }}</h5><h3>${{ number_format($stats['total_revenue'], 2) }}</h3></div></div></div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">{{ __('Top Products') }}</div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead><tr><th>{{ __('Product') }}</th><th>{{ __('Sold') }}</th></tr></thead>
                        <tbody>
                            @foreach($stats['top_products'] as $p)
                            <tr><td>{{ $p->name }}</td><td>{{ $p->total_sold }}</td></tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">{{ __('Top Categories') }}</div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead><tr><th>{{ __('Category') }}</th><th>{{ __('Orders') }}</th></tr></thead>
                        <tbody>
                            @foreach($stats['top_categories'] as $c)
                            <tr><td>{{ app()->getLocale() === 'ar' ? $c->name_ar : $c->name_en }}</td><td>{{ $c->orders_count }}</td></tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
