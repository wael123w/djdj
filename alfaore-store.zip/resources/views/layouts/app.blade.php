<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ config('app.direction', 'rtl') }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', config('settings.site_name', 'Alfaore Store'))</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    @if(app()->getLocale() === 'ar')
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>body{font-family:'Cairo',sans-serif;}</style>
    @endif
    <style>
        :root{--primary:#7b1fa2;--primary-dark:#4a148c;--accent:#00c853;}
        .bg-primary-custom{background:linear-gradient(135deg,var(--primary),var(--primary-dark))!important;}
        .btn-primary-custom{background:var(--primary);border:none;}
        .btn-primary-custom:hover{background:var(--primary-dark);}
        .card-hover{transition:transform .2s;}
        .card-hover:hover{transform:translateY(-5px);}
        .navbar-brand{font-weight:700;font-size:1.5rem;}
        .category-card{border-radius:16px;overflow:hidden;}
        .product-card{border-radius:12px;border:none;box-shadow:0 2px 8px rgba(0,0,0,.08);}
        .badge-status{padding:.4em .8em;border-radius:20px;font-size:.75rem;}
        .footer{background:#1a1a2e;color:#fff;padding:3rem 0;margin-top:auto;}
        html,body{height:100%;}
        body{display:flex;flex-direction:column;}
        main{flex:1;}
    </style>
    @stack('styles')
</head>
<body>
    @include('layouts.navbar')
    <main>
        @if(session('success'))
        <div class="container mt-3"><div class="alert alert-success alert-dismissible fade show">{{ session('success') }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
        @endif
        @if(session('error'))
        <div class="container mt-3"><div class="alert alert-danger alert-dismissible fade show">{{ session('error') }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
        @endif
        @yield('content')
    </main>
    @include('layouts.footer')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
