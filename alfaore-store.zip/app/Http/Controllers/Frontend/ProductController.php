<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\Contracts\CategoryRepositoryInterface;

class ProductController extends Controller
{
    public function __construct(
        private ProductRepositoryInterface $productRepo,
        private CategoryRepositoryInterface $categoryRepo,
    ) {}

    public function index()
    {
        $filters = request()->only(['category_id', 'search', 'min_price', 'max_price', 'sort']);
        $products = $this->productRepo->getAll($filters, 24);
        $categories = $this->categoryRepo->getAll(['active' => true, 'root_only' => true]);

        return view('frontend.products.index', compact('products', 'categories'));
    }

    public function show(string $slug)
    {
        $product = $this->productRepo->findBySlug($slug);
        if (!$product) abort(404);

        $relatedProducts = $this->productRepo->getByCategory($product->category_id)->take(8);

        return view('frontend.products.show', compact('product', 'relatedProducts'));
    }
}
