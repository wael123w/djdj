<?php

namespace App\Services;

use App\Models\LoyaltyPoint;
use App\Models\Order;
use App\Models\User;

class LoyaltyService
{
    private int $pointsPerCurrency = 10;
    private float $pointValue = 0.01;

    public function awardPointsForOrder(Order $order): void
    {
        $points = (int) ($order->total * $this->pointsPerCurrency);
        if ($points <= 0) return;

        LoyaltyPoint::create([
            'user_id' => $order->user_id,
            'points' => $points,
            'type' => 'earn',
            'description_ar' => "نقاط مكافأة للطلب #{$order->order_number}",
            'description_en' => "Loyalty points for order #{$order->order_number}",
            'order_id' => $order->id,
            'expires_at' => now()->addYear(),
        ]);

        $order->user->increment('loyalty_points', $points);
    }

    public function redeemPoints(User $user, int $points, Order $order): void
    {
        LoyaltyPoint::create([
            'user_id' => $user->id,
            'points' => -$points,
            'type' => 'redeem',
            'description_ar' => "استبدال نقاط للطلب #{$order->order_number}",
            'description_en' => "Points redeemed for order #{$order->order_number}",
            'order_id' => $order->id,
        ]);
    }

    public function refundPoints(User $user, int $points, Order $order): void
    {
        LoyaltyPoint::create([
            'user_id' => $user->id,
            'points' => $points,
            'type' => 'bonus',
            'description_ar' => "استرداد نقاط للطلب الملغى #{$order->order_number}",
            'description_en' => "Refunded points for cancelled order #{$order->order_number}",
            'order_id' => $order->id,
        ]);
        $user->increment('loyalty_points', $points);
    }

    public function calculateRedemptionValue(int $points): float
    {
        return $points * $this->pointValue;
    }

    public function pointsForAmount(float $amount): int
    {
        return (int) ($amount / $this->pointValue);
    }

    public function getAvailablePoints(User $user): int
    {
        return LoyaltyPoint::where('user_id', $user->id)
            ->where(function ($q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>', now());
            })->sum('points');
    }
}
