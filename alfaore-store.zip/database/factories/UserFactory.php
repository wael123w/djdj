<?php

namespace Database\Factories;

use App\Enums\UserRole;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    protected $model = \App\Models\User::class;

    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'phone' => fake()->phoneNumber(),
            'role' => UserRole::USER,
            'is_active' => true,
            'referral_code' => Str::random(8),
            'balance' => fake()->randomFloat(2, 0, 500),
            'loyalty_points' => fake()->numberBetween(0, 1000),
            'remember_token' => Str::random(10),
        ];
    }
}
