@extends('layouts.app')
@section('title', __('Shopping Cart'))
@section('content')
<div class="container py-5">
    <h2 class="mb-4">{{ __('Shopping Cart') }}</h2>
    @if($items->isEmpty())
    <div class="text-center py-5">
        <i class="bi bi-cart-x display-1 text-muted"></i>
        <p class="mt-3">{{ __('Your cart is empty') }}</p>
        <a href="{{ route('products.index') }}" class="btn btn-primary-custom">{{ __('Continue Shopping') }}</a>
    </div>
    @else
    <div class="row">
        <div class="col-lg-8">
            @foreach($items as $item)
            <div class="card mb-3">
                <div class="card-body d-flex align-items-center">
                    <img src="{{ $item->product->image ? asset('storage/' . $item->product->image) : 'https://via.placeholder.com/80' }}" class="rounded" style="width:80px;height:80px;object-fit:cover;" alt="">
                    <div class="ms-3 flex-grow-1">
                        <h6>{{ $item->product->name }}</h6>
                        <p class="text-primary mb-0">${{ number_format($item->product->final_price, 2) }}</p>
                    </div>
                    <form action="{{ route('cart.update', $item->id) }}" method="POST" class="d-flex align-items-center">
                        @csrf @method('PUT')
                        <input type="number" name="quantity" value="{{ $item->quantity }}" min="1" class="form-control" style="width:70px;">
                        <button type="submit" class="btn btn-sm btn-outline-primary ms-2"><i class="bi bi-arrow-repeat"></i></button>
                    </form>
                    <form action="{{ route('cart.destroy', $item->id) }}" method="POST" class="ms-3">
                        @csrf @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-primary-custom text-white">{{ __('Order Summary') }}</div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>{{ __('Subtotal') }}</span>
                        <span class="fw-bold">${{ number_format($total, 2) }}</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-3">
                        <span class="fw-bold">{{ __('Total') }}</span>
                        <span class="fw-bold text-primary fs-5">${{ number_format($total, 2) }}</span>
                    </div>
                    <form action="{{ route('orders.store') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">{{ __('Coupon Code') }}</label>
                            <input type="text" name="coupon_code" class="form-control" placeholder="{{ __('Enter code') }}">
                        </div>
                        <button type="submit" class="btn btn-primary-custom w-100 btn-lg">{{ __('Place Order') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
