<?php

namespace App\Repositories\Contracts;

use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface UserRepositoryInterface
{
    public function getAll(array $filters = [], int $perPage = 15): LengthAwarePaginator;
    public function findById(int $id): ?User;
    public function findByEmail(string $email): ?User;
    public function findByReferralCode(string $code): ?User;
    public function create(array $data): User;
    public function update(User $user, array $data): User;
    public function updateBalance(User $user, float $amount): User;
    public function updateLoyaltyPoints(User $user, int $points): User;
}
