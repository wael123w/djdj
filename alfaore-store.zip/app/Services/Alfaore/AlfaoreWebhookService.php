<?php

namespace App\Services\Alfaore;

use App\Models\Order;
use Illuminate\Support\Facades\Log;

class AlfaoreWebhookService
{
    public function handle(array $payload): void
    {
        Log::info('Alfaore webhook received', $payload);
        $orderId = $payload['order_id'] ?? null;
        $status = $payload['status'] ?? null;

        if (!$orderId || !$status) {
            Log::warning('Invalid Alfaore webhook payload', $payload);
            return;
        }

        $order = Order::where('alfaore_order_id', $orderId)->first();
        if (!$order) {
            Log::warning('Order not found for Alfaore webhook', ['alfaore_id' => $orderId]);
            return;
        }

        $oldStatus = $order->status;
        $order->update([
            'status' => $status,
            'alfaore_response' => array_merge($order->alfaore_response ?? [], $payload),
        ]);

        if ($oldStatus !== $status) {
            event(new \App\Events\OrderStatusUpdated($order, $status));
        }

        Log::info('Alfaore webhook processed', ['order_id' => $order->id, 'status' => $status]);
    }

    public function verifySignature(string $payload, string $signature): bool
    {
        $secret = config('alfaore.webhook_secret');
        if (empty($secret)) return true;
        $computed = hash_hmac('sha256', $payload, $secret);
        return hash_equals($computed, $signature);
    }
}
