<?php

namespace App\Listeners;

use App\Events\OrderCreated;
use App\Events\OrderStatusUpdated;
use App\Services\NotificationService;

class SendOrderNotification
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(OrderCreated|OrderStatusUpdated $event): void
    {
        $order = $event->order;
        $type = $event instanceof OrderCreated ? 'order_created' : 'order_updated';

        $this->notificationService->notifyUser($order->user, $type, [
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'status' => $order->status->value,
            'total' => $order->total,
        ]);

        $this->notificationService->notifyAdmins($type, [
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'user' => $order->user->name,
            'total' => $order->total,
        ]);
    }
}
