<?php

namespace App\Repositories;

use App\Models\Product;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Cache;

class ProductRepository implements ProductRepositoryInterface
{
    public function getAll(array $filters = [], int $perPage = 15): LengthAwarePaginator
    {
        $query = Product::with('category')->active();

        if (!empty($filters['category_id'])) {
            $query->where('category_id', $filters['category_id']);
        }
        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->where('name_ar', 'like', "%{$search}%")
                  ->orWhere('name_en', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%");
            });
        }
        if (!empty($filters['min_price'])) {
            $query->where('price', '>=', $filters['min_price']);
        }
        if (!empty($filters['max_price'])) {
            $query->where('price', '<=', $filters['max_price']);
        }
        if (!empty($filters['featured'])) {
            $query->featured();
        }
        if (!empty($filters['sort'])) {
            match ($filters['sort']) {
                'price_asc' => $query->orderBy('price', 'asc'),
                'price_desc' => $query->orderBy('price', 'desc'),
                'popular' => $query->orderBy('sold_count', 'desc'),
                'rating' => $query->orderBy('rating', 'desc'),
                default => $query->latest(),
            };
        } else {
            $query->latest();
        }

        return $query->paginate($perPage);
    }

    public function findById(int $id): ?Product
    {
        return Cache::remember("product.{$id}", 3600, fn() => Product::with(['category', 'reviews.user'])->find($id));
    }

    public function findBySlug(string $slug): ?Product
    {
        return Cache::remember("product.slug.{$slug}", 3600, fn() => Product::with(['category', 'reviews.user'])->where('slug', $slug)->first());
    }

    public function findByAlfaoreId(int $alfaoreId): ?Product
    {
        return Product::where('alfaore_product_id', $alfaoreId)->first();
    }

    public function create(array $data): Product
    {
        $product = Product::create($data);
        $this->clearCache();
        return $product;
    }

    public function update(Product $product, array $data): Product
    {
        $product->update($data);
        $this->clearProductCache($product);
        return $product->fresh();
    }

    public function delete(Product $product): bool
    {
        $this->clearProductCache($product);
        return $product->delete();
    }

    public function getFeatured(int $limit = 8): Collection
    {
        return Cache::remember('products.featured', 1800, fn() =>
            Product::active()->featured()->with('category')->limit($limit)->get()
        );
    }

    public function getByCategory(int $categoryId, array $filters = []): LengthAwarePaginator
    {
        $filters['category_id'] = $categoryId;
        return $this->getAll($filters);
    }

    public function syncFromAlfaore(array $products): array
    {
        $created = 0;
        $updated = 0;

        foreach ($products as $item) {
            $data = [
                'alfaore_product_id' => $item['id'],
                'name_ar' => $item['name'],
                'name_en' => $item['name'],
                'slug' => 'alfaore-' . $item['id'] . '-' . \Str::slug($item['name']),
                'price' => $item['price'] * 1.15,
                'cost_price' => $item['price'],
                'alfaore_category_name' => $item['category_name'] ?? null,
                'alfaore_params' => $item['params'] ?? [],
                'qty_values' => $item['qty_values'],
                'product_type' => $item['product_type'],
                'is_active' => $item['available'] ?? true,
            ];

            $existing = $this->findByAlfaoreId($item['id']);
            if ($existing) {
                $this->update($existing, $data);
                $updated++;
            } else {
                $data['category_id'] = 1;
                $data['stock'] = 9999;
                $this->create($data);
                $created++;
            }
        }

        $this->clearCache();
        return ['created' => $created, 'updated' => $updated];
    }

    private function clearProductCache(Product $product): void
    {
        Cache::forget("product.{$product->id}");
        Cache::forget("product.slug.{$product->slug}");
        Cache::forget('products.featured');
    }

    private function clearCache(): void
    {
        Cache::flush();
    }
}
