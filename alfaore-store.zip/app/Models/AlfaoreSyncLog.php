<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AlfaoreSyncLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'type', 'status', 'items_processed', 'items_created', 'items_updated',
        'error_message', 'details', 'started_at', 'finished_at',
    ];

    protected function casts(): array
    {
        return [
            'items_processed' => 'integer',
            'items_created' => 'integer',
            'items_updated' => 'integer',
            'details' => 'array',
            'started_at' => 'datetime',
            'finished_at' => 'datetime',
        ];
    }
}
