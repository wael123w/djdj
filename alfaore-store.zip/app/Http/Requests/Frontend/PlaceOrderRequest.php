<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class PlaceOrderRequest extends FormRequest
{
    public function authorize(): bool { return auth()->check(); }

    public function rules(): array
    {
        return [
            'coupon_code' => 'nullable|string|max:50',
            'use_loyalty_points' => 'nullable|boolean',
            'notes' => 'nullable|string|max:1000',
        ];
    }
}
