<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Frontend\PlaceOrderRequest;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\OrderService;

class OrderController extends Controller
{
    public function __construct(
        private OrderService $orderService,
        private OrderRepositoryInterface $orderRepo,
    ) {}

    public function index()
    {
        $orders = $this->orderRepo->getUserOrders(auth()->id());
        return view('frontend.orders.index', compact('orders'));
    }

    public function show(int $id)
    {
        $order = $this->orderRepo->findById($id);
        if (!$order || $order->user_id !== auth()->id()) abort(403);
        return view('frontend.orders.show', compact('order'));
    }

    public function store(PlaceOrderRequest $request)
    {
        try {
            $order = $this->orderService->placeOrder(auth()->id(), $request->validated());
            return redirect()->route('orders.show', $order)->with('success', __('Order placed successfully'));
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function cancel(int $id)
    {
        $order = $this->orderRepo->findById($id);
        if (!$order || $order->user_id !== auth()->id()) abort(403);

        try {
            $this->orderService->cancelOrder($order);
            return back()->with('success', __('Order cancelled'));
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
