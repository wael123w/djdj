<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Frontend\AddToCartRequest;
use App\Services\CartService;

class CartController extends Controller
{
    public function __construct(private CartService $cartService) {}

    public function index()
    {
        $items = $this->cartService->getCartItems(auth()->id());
        $total = $this->cartService->getCartTotal(auth()->id());
        return view('frontend.cart.index', compact('items', 'total'));
    }

    public function store(AddToCartRequest $request)
    {
        $this->cartService->addToCart(
            auth()->id(),
            $request->product_id,
            $request->quantity,
            $request->params ?? []
        );

        return back()->with('success', __('Product added to cart'));
    }

    public function update(int $cartId)
    {
        $this->cartService->updateCartItem($cartId, request('quantity', 1));
        return back()->with('success', __('Cart updated'));
    }

    public function destroy(int $cartId)
    {
        $this->cartService->removeFromCart($cartId);
        return back()->with('success', __('Item removed'));
    }
}
