<?php

namespace App\Http\Controllers\Auth;

use App\Enums\UserRole;
use App\Events\UserRegistered;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(RegisterRequest $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'role' => UserRole::USER,
            'referral_code' => Str::random(8),
            'locale' => app()->getLocale(),
        ]);

        event(new Registered($user));
        event(new UserRegistered($user, $request->referral_code));

        Auth::login($user);

        return redirect()->route('home');
    }
}
