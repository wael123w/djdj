<?php

namespace App\Models;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'order_number', 'user_id', 'vendor_id', 'status', 'payment_status',
        'subtotal', 'discount', 'tax', 'total', 'profit', 'coupon_code', 'coupon_id',
        'loyalty_points_used', 'alfaore_order_id', 'alfaore_order_uuid', 'alfaore_response',
        'payment_method', 'transaction_id', 'notes', 'ip_address', 'user_agent', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'status' => OrderStatus::class,
            'payment_status' => PaymentStatus::class,
            'subtotal' => 'decimal:4',
            'discount' => 'decimal:4',
            'tax' => 'decimal:4',
            'total' => 'decimal:4',
            'profit' => 'decimal:4',
            'loyalty_points_used' => 'integer',
            'alfaore_response' => 'array',
            'completed_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function vendor(): BelongsTo { return $this->belongsTo(User::class, 'vendor_id'); }
    public function items(): HasMany { return $this->hasMany(OrderItem::class); }
    public function coupon(): BelongsTo { return $this->belongsTo(Coupon::class); }
    public function review(): HasMany { return $this->hasMany(Review::class); }

    public function scopeToday($query) { return $query->whereDate('created_at', today()); }
    public function scopePending($query) { return $query->where('status', OrderStatus::PENDING); }
    public function scopeCompleted($query) { return $query->where('status', OrderStatus::COMPLETED); }
    public function scopeCancelled($query) { return $query->where('status', OrderStatus::CANCELLED); }
    public function scopePaid($query) { return $query->where('payment_status', PaymentStatus::PAID); }
}
