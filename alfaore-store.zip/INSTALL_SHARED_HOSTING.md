# دليل التثبيت على الاستضافة المشتركة (بدون Terminal)

> هذا الدليل مخصص للاستضافات المشتركة التي **لا تدعم SSH/Terminal**.

---

## 📋 المتطلبات

- استضافة تدعم PHP 8.3+
- MySQL 8.0+
- مساحة 500MB على الأقل
- cPanel (أو أي لوحة تحكم مشابهة)

---

## 🚀 طريقة التثبيت (3 خطوات فقط)

### الخطوة 1: تثبيت Composer محلياً (على جهازك)

> **لماذا؟** مجلد `vendor` كبير جداً ويحتوي على آلاف الملفات. يجب تثبيته على جهازك ثم رفعه.

**إذا كان لديك PHP 8.3 على جهازك:**
```bash
# 1. فك الضغط
unzip alfaore-store.zip

# 2. ادخل للمجلد
cd alfaore-store

# 3. ثبت الـ Dependencies
composer install --no-dev --optimize-autoloader
```

**إذا لم يكن لديك PHP محلي:**
1. اذهب لـ [php-download.com](https://php-download.com/package/laravel/framework)
2. أو استخدم [getcomposer.org](https://getcomposer.org/download/) لتثبيت Composer
3. أو استخدم XAMPP/WAMP

**بديل: استخدام خدمة Composer Online:**
- ارفع ملف `composer.json` فقط لـ [composerize.com](https://composerize.com)
- أو استخدم [deployer.org](https://deployer.org)

---

### الخطوة 2: رفع الملفات للاستضافة

1. افتح **cPanel** → **File Manager**
2. اذهب لـ `public_html` (أو مجلد موقعك)
3. ارفع جميع الملفات (بما فيها `vendor/`)
4. تأكد من أن هذه المجلدات قابلة للكتابة (CHMOD 755):
   - `storage/`
   - `storage/framework/`
   - `storage/logs/`
   - `bootstrap/cache/`

---

### الخطوة 3: تشغيل المثبت

1. افتح المتصفح وادخل إلى:
   ```
   https://your-domain.com/install.php
   ```
2. اتبع الخطوات:
   - **فحص المتطلبات** - تأكد من توفر كل شيء
   - **إعدادات قاعدة البيانات** - أدخل بيانات DB من cPanel
   - **إعدادات API** - أدخل توكن Alfaore
   - **استيراد قاعدة البيانات** - يتم تلقائياً
3. بعد الانتهاء:
   - **احذف `install.php` فوراً!**
   - سجل الدخول بـ `admin@alfaore.com` / `password`
   - غيّر كلمة المرور

---

## 🗄️ طريقة بديلة: استيراد قاعدة البيانات يدوياً

إذا فشل المثبت في استيراد SQL:

1. افتح **cPanel** → **phpMyAdmin**
2. أنشئ قاعدة بيانات جديدة
3. اختر القاعدة → تبويب **Import**
4. اختر ملف `database.sql` من جهازك
5. اضغط **Go**

---

## ⚙️ إعداد Cron Job (مهم جداً)

للمزامنة التلقائية مع Alfaore API:

1. افتح **cPanel** → **Cron Jobs**
2. أضف هذا الأمر كل دقيقة:
   ```bash
   * * * * * cd /home/username/public_html && php artisan schedule:run >> /dev/null 2>&1
   ```
   (استبدل `username` باسم المستخدم الخاص بك)

---

## 🔑 بيانات الدخول الافتراضية

| | |
|---|---|
| **البريد** | `admin@alfaore.com` |
| **كلمة المرور** | `password` |

---

## ❌ حل المشاكل الشائعة

### مشكلة: "vendor directory not found"
**الحل:** لم تقم بتثبيت Composer. شغل `composer install` على جهازك ثم ارفع مجلد `vendor`.

### مشكلة: "500 Internal Server Error"
**الحل:**
1. تأكد من CHMOD 755 للمجلدات: `storage`, `bootstrap/cache`
2. تأكد من وجود ملف `.env`
3. تأكد من إصدار PHP 8.3+

### مشكلة: "Access denied for database"
**الحل:** تأكد من صحة بيانات قاعدة البيانات في ملف `.env`

### مشكلة: الصفحة بيضاء
**الحل:** افتح `index.php` واضف في البداية:
```php
ini_set('display_errors', 1);
error_reporting(E_ALL);
```

---

## 📞 دعم

إذا واجهت أي مشكلة، تأكد من:
1. ✅ رفع جميع الملفات بما فيها `vendor/`
2. ✅ إنشاء قاعدة بيانات واستيراد `database.sql`
3. ✅ تعديل ملف `.env` بالبيانات الصحيحة
4. ✅ حذف `install.php` بعد الانتهاء
