<?php

namespace App\Services;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Events\OrderCreated;
use App\Events\OrderStatusUpdated;
use App\Models\Order;
use App\Models\OrderItem;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Services\Alfaore\AlfaoreApiService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class OrderService
{
    public function __construct(
        private OrderRepositoryInterface $orderRepo,
        private ProductRepositoryInterface $productRepo,
        private UserRepositoryInterface $userRepo,
        private AlfaoreApiService $alfaoreApi,
        private CouponService $couponService,
        private LoyaltyService $loyaltyService,
        private CartService $cartService,
    ) {}

    public function placeOrder(int $userId, array $data): Order
    {
        return DB::transaction(function () use ($userId, $data) {
            $user = $this->userRepo->findById($userId);
            $cartItems = $this->cartService->getCartItems($userId);

            if ($cartItems->isEmpty()) {
                throw new \Exception(__('Cart is empty'));
            }

            $subtotal = 0;
            $costTotal = 0;
            $orderItems = [];

            foreach ($cartItems as $cartItem) {
                $product = $cartItem->product;
                $qty = $cartItem->quantity;
                $price = $product->final_price;
                $itemSubtotal = $price * $qty;
                $itemCost = $product->cost_price * $qty;

                $subtotal += $itemSubtotal;
                $costTotal += $itemCost;

                $orderItems[] = [
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'price' => $price,
                    'quantity' => $qty,
                    'subtotal' => $itemSubtotal,
                    'params' => $cartItem->params,
                ];
            }

            $discount = 0;
            $coupon = null;
            if (!empty($data['coupon_code'])) {
                $coupon = $this->couponService->validate($data['coupon_code'], $subtotal, $userId);
                if ($coupon) {
                    $discount = $this->couponService->calculateDiscount($coupon, $subtotal);
                }
            }

            $loyaltyPointsUsed = 0;
            $loyaltyDiscount = 0;
            if (!empty($data['use_loyalty_points']) && $user->loyalty_points > 0) {
                $loyaltyDiscount = $this->loyaltyService->calculateRedemptionValue($user->loyalty_points);
                $loyaltyPointsUsed = min($user->loyalty_points, $this->loyaltyService->pointsForAmount($loyaltyDiscount));
            }

            $total = max(0, $subtotal - $discount - $loyaltyDiscount);
            $profit = $total - $costTotal;

            if ($user->balance < $total) {
                throw new \Exception(__('Insufficient balance'));
            }

            $order = $this->orderRepo->create([
                'order_number' => 'ORD-' . strtoupper(Str::random(10)),
                'user_id' => $userId,
                'status' => OrderStatus::PENDING,
                'payment_status' => PaymentStatus::PAID,
                'subtotal' => $subtotal,
                'discount' => $discount,
                'tax' => 0,
                'total' => $total,
                'profit' => $profit,
                'coupon_code' => $coupon?->code,
                'coupon_id' => $coupon?->id,
                'loyalty_points_used' => $loyaltyPointsUsed,
                'payment_method' => 'balance',
                'notes' => $data['notes'] ?? null,
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ]);

            foreach ($orderItems as $item) {
                $item['order_id'] = $order->id;
                OrderItem::create($item);
            }

            $this->userRepo->updateBalance($user, -$total);

            if ($loyaltyPointsUsed > 0) {
                $this->loyaltyService->redeemPoints($user, $loyaltyPointsUsed, $order);
            }

            if ($coupon) {
                $this->couponService->recordUsage($coupon, $user, $order, $discount);
            }

            $this->cartService->clearCart($userId);
            $this->processAlfaoreOrder($order);
            event(new OrderCreated($order));

            return $order->fresh('items');
        });
    }

    private function processAlfaoreOrder(Order $order): void
    {
        foreach ($order->items as $item) {
            $product = $item->product;
            if (!$product->alfaore_product_id) continue;

            try {
                $params = $item->params ?? [];
                $response = $this->alfaoreApi->createOrder(
                    $product->alfaore_product_id,
                    $item->quantity,
                    $params
                );

                if (($response['status'] ?? '') === 'OK') {
                    $order->update([
                        'alfaore_order_id' => $response['data']['order_id'] ?? null,
                        'alfaore_order_uuid' => $response['data']['order_uuid'] ?? null,
                        'status' => OrderStatus::from($response['data']['status'] ?? 'wait'),
                        'alfaore_response' => $response,
                    ]);
                    $item->update([
                        'alfaore_replay' => $response['data']['replay_api'] ?? null,
                    ]);
                }
            } catch (\Exception $e) {
                Log::error('Alfaore order failed', [
                    'order_id' => $order->id,
                    'item_id' => $item->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    public function cancelOrder(Order $order): Order
    {
        if (!in_array($order->status, [OrderStatus::PENDING, OrderStatus::WAIT])) {
            throw new \Exception(__('Order cannot be cancelled'));
        }

        return DB::transaction(function () use ($order) {
            $this->userRepo->updateBalance($order->user, $order->total);

            if ($order->loyalty_points_used > 0) {
                $this->loyaltyService->refundPoints($order->user, $order->loyalty_points_used, $order);
            }

            $order->update([
                'status' => OrderStatus::CANCELLED,
                'payment_status' => PaymentStatus::REFUNDED,
            ]);

            event(new OrderStatusUpdated($order, OrderStatus::CANCELLED));
            return $order->fresh();
        });
    }

    public function updateStatus(Order $order, OrderStatus $status): Order
    {
        $order->update(['status' => $status]);

        if ($status === OrderStatus::COMPLETED && !$order->completed_at) {
            $order->update(['completed_at' => now()]);
            $this->loyaltyService->awardPointsForOrder($order);
        }

        event(new OrderStatusUpdated($order, $status));
        return $order->fresh();
    }
}
