<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>{{ config('settings.site_name', 'Alfaore Store') }}</h5>
                <p class="text-muted">{{ __('Your trusted digital store') }}</p>
            </div>
            <div class="col-md-4">
                <h5>{{ __('Quick Links') }}</h5>
                <ul class="list-unstyled">
                    <li><a href="{{ route('home') }}" class="text-decoration-none text-light">{{ __('Home') }}</a></li>
                    <li><a href="{{ route('products.index') }}" class="text-decoration-none text-light">{{ __('Products') }}</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>{{ __('Contact') }}</h5>
                <p class="text-muted">{{ config('settings.contact_email', 'support@alfaore.com') }}</p>
            </div>
        </div>
        <hr class="my-4">
        <div class="text-center text-muted">
            &copy; {{ date('Y') }} {{ config('settings.site_name', 'Alfaore Store') }}. {{ __('All rights reserved.') }}
        </div>
    </div>
</footer>
