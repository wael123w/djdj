<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            ['key' => 'site_name', 'value' => 'متجر الفاعوري', 'type' => 'string', 'group' => 'general'],
            ['key' => 'site_logo', 'value' => '', 'type' => 'string', 'group' => 'general'],
            ['key' => 'site_description', 'value' => 'متجر إلكتروني متكامل', 'type' => 'string', 'group' => 'general'],
            ['key' => 'contact_email', 'value' => 'support@alfaore.com', 'type' => 'string', 'group' => 'general'],
            ['key' => 'contact_phone', 'value' => '', 'type' => 'string', 'group' => 'general'],
            ['key' => 'maintenance_mode', 'value' => '0', 'type' => 'boolean', 'group' => 'general'],
            ['key' => 'vendor_enabled', 'value' => '0', 'type' => 'boolean', 'group' => 'marketplace'],
            ['key' => 'referral_enabled', 'value' => '1', 'type' => 'boolean', 'group' => 'referral'],
            ['key' => 'referral_commission', 'value' => '5', 'type' => 'float', 'group' => 'referral'],
            ['key' => 'loyalty_enabled', 'value' => '1', 'type' => 'boolean', 'group' => 'loyalty'],
            ['key' => 'loyalty_points_per_currency', 'value' => '10', 'type' => 'integer', 'group' => 'loyalty'],
            ['key' => 'loyalty_point_value', 'value' => '0.01', 'type' => 'float', 'group' => 'loyalty'],
        ];

        foreach ($settings as $setting) {
            Setting::create($setting);
        }
    }
}
