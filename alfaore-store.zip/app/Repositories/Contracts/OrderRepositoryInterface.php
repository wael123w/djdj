<?php

namespace App\Repositories\Contracts;

use App\Models\Order;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface OrderRepositoryInterface
{
    public function getAll(array $filters = [], int $perPage = 15): LengthAwarePaginator;
    public function findById(int $id): ?Order;
    public function findByOrderNumber(string $orderNumber): ?Order;
    public function findByAlfaoreId(string $alfaoreId): ?Order;
    public function create(array $data): Order;
    public function update(Order $order, array $data): Order;
    public function getUserOrders(int $userId, array $filters = []): LengthAwarePaginator;
    public function getTodayStats(): array;
    public function getStatistics(string $period = 'today'): array;
}
