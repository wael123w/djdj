# Alfaore Store - متجر الفاعوري

Professional E-commerce Platform integrated with Alfaore API.

## Requirements
- PHP 8.3+
- MySQL 8.0+
- Composer 2.x
- Node.js 20+

## Installation

### 1. Extract & Install Dependencies
```bash
cd alfaore-store
composer install --no-dev --optimize-autoloader
npm install && npm run build
```

### 2. Environment Setup
```bash
cp .env.example .env
php artisan key:generate
```
Edit `.env` and set your database credentials and Alfaore API token.

### 3. Database
```bash
php artisan migrate --seed
```

### 4. Storage Link
```bash
php artisan storage:link
```

### 5. Queue Worker (Required for orders)
```bash
php artisan queue:work --sleep=3 --tries=3
```

### 6. Scheduler (Required for auto-sync)
Add to crontab:
```bash
* * * * * cd /path/to/alfaore-store && php artisan schedule:run >> /dev/null 2>&1
```

### 7. Web Server
Point your domain to the `public/` directory.

## Default Admin Account
- Email: `admin@alfaore.com`
- Password: `password`

## Alfaore API Configuration
Set these in your `.env`:
```
ALFAORE_BASE_URL=https://api.alfaore-store.com/
ALFAORE_API_TOKEN=your_api_token_here
ALFAORE_WEBHOOK_SECRET=your_webhook_secret_here
```

## Features
- Full Alfaore API Integration
- Service Layer + Repository Pattern + SOLID
- Multi-language (AR/EN)
- Multi-currency
- Coupons & Discounts
- Loyalty Points
- Referral System
- Activity Logs
- Real-time Notifications
- Product Reviews
- Wishlist
- Product Comparison
- Vendor Marketplace
- Webhooks
- Auto-sync every 5 minutes
- Admin Dashboard with Statistics
- Laravel Queues, Cache, Events, Policies, Middleware

## License
MIT
