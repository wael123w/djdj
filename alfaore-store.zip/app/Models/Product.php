<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'category_id', 'vendor_id', 'name_ar', 'name_en', 'slug', 'description_ar',
        'description_en', 'image', 'gallery', 'price', 'sale_price', 'cost_price',
        'alfaore_product_id', 'alfaore_category_name', 'alfaore_params', 'qty_values',
        'product_type', 'min_qty', 'max_qty', 'stock', 'is_active', 'is_featured',
        'rating', 'reviews_count', 'sold_count', 'meta',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:4',
            'sale_price' => 'decimal:4',
            'cost_price' => 'decimal:4',
            'rating' => 'decimal:1',
            'gallery' => 'array',
            'alfaore_params' => 'array',
            'qty_values' => 'array',
            'meta' => 'array',
            'is_active' => 'boolean',
            'is_featured' => 'boolean',
            'min_qty' => 'integer',
            'max_qty' => 'integer',
            'stock' => 'integer',
            'reviews_count' => 'integer',
            'sold_count' => 'integer',
        ];
    }

    public function category(): BelongsTo { return $this->belongsTo(Category::class); }
    public function vendor(): BelongsTo { return $this->belongsTo(User::class, 'vendor_id'); }
    public function orderItems(): HasMany { return $this->hasMany(OrderItem::class); }
    public function reviews(): HasMany { return $this->hasMany(Review::class); }
    public function wishlists(): HasMany { return $this->hasMany(Wishlist::class); }
    public function carts(): HasMany { return $this->hasMany(Cart::class); }

    public function getNameAttribute(): string
    {
        return app()->getLocale() === 'ar' ? $this->name_ar : $this->name_en;
    }

    public function getDescriptionAttribute(): ?string
    {
        return app()->getLocale() === 'ar' ? $this->description_ar : $this->description_en;
    }

    public function getFinalPriceAttribute(): float
    {
        return $this->sale_price ?? $this->price;
    }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeFeatured($query) { return $query->where('is_featured', true); }
    public function scopeInStock($query) { return $query->where('stock', '>', 0); }
}
