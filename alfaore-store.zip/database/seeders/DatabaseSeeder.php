<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            LanguageSeeder::class,
            CurrencySeeder::class,
            UserSeeder::class,
            CategorySeeder::class,
            SettingSeeder::class,
        ]);
    }
}
