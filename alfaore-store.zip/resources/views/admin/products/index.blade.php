@extends('layouts.app')
@section('title', __('Products'))
@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>{{ __('Products') }}</h2>
        <a href="{{ route('admin.products.create') }}" class="btn btn-primary-custom">{{ __('Add Product') }}</a>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark">
                        <tr><th>#</th><th>{{ __('Name') }}</th><th>{{ __('Category') }}</th><th>{{ __('Price') }}</th><th>{{ __('Stock') }}</th><th>{{ __('Status') }}</th><th>{{ __('Actions') }}</th></tr>
                    </thead>
                    <tbody>
                        @foreach($products as $p)
                        <tr>
                            <td>{{ $p->id }}</td>
                            <td>{{ $p->name }}</td>
                            <td>{{ $p->category?->name }}</td>
                            <td>${{ number_format($p->final_price, 2) }}</td>
                            <td>{{ $p->stock }}</td>
                            <td><span class="badge bg-{{ $p->is_active ? 'success' : 'danger' }}">{{ $p->is_active ? __('Active') : __('Inactive') }}</span></td>
                            <td>
                                <a href="{{ route('admin.products.edit', $p->id) }}" class="btn btn-sm btn-outline-primary">{{ __('Edit') }}</a>
                                <form action="{{ route('admin.products.destroy', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Are you sure?') }}')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $products->links() }}
        </div>
    </div>
</div>
@endsection
