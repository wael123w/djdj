<?php
/**
 * Alfaore Store - One-Click Installer for Shared Hosting
 * No SSH/Terminal required. Upload files and open in browser.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = $_GET['step'] ?? 'welcome';
$messages = [];
$errors = [];

function msg($text) { global $messages; $messages[] = $text; }
function err($text) { global $errors; $errors[] = $text; }

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تثبيت متجر الفاعوري</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f5f5f5; }
        .installer-box { max-width: 750px; margin: 40px auto; }
        .step-active { background: #7b1fa2; color: white; }
        .step-done { background: #00c853; color: white; }
        .step-pending { background: #e0e0e0; color: #666; }
        .step-item { padding: 8px 14px; border-radius: 8px; margin: 3px; font-weight: 600; font-size: 0.85rem; }
        .log-box { background: #1a1a2e; color: #00ff88; padding: 15px; border-radius: 8px; font-family: monospace; max-height: 300px; overflow-y: auto; font-size: 0.85rem; }
        .method-box { border: 2px dashed #7b1fa2; border-radius: 12px; padding: 20px; margin: 10px 0; background: #faf5ff; }
    </style>
</head>
<body>
<div class="container installer-box">
    <div class="card shadow">
        <div class="card-header text-white text-center" style="background: linear-gradient(135deg,#7b1fa2,#4a148c);">
            <h3 class="mb-0">🔧 تثبيت متجر الفاعوري</h3>
            <small>بدون Terminal - يعمل على أي استضافة مشتركة</small>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-center mb-4 flex-wrap">
                <div class="step-item <?= $step=='welcome'?'step-active':($step>'welcome'?'step-done':'step-pending') ?>">1. الترحيب</div>
                <div class="step-item <?= $step=='check'?'step-active':($step>'check'?'step-done':'step-pending') ?>">2. فحص المتطلبات</div>
                <div class="step-item <?= $step=='env'?'step-active':($step>'env'?'step-done':'step-pending') ?>">3. الإعدادات</div>
                <div class="step-item <?= $step=='db'?'step-active':($step>'db'?'step-done':'step-pending') ?>">4. قاعدة البيانات</div>
                <div class="step-item <?= $step=='finish'?'step-active':'step-pending' ?>">5. الانتهاء</div>
            </div>

            <?php if(!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach($errors as $e) echo "<div>❌ $e</div>"; ?>
            </div>
            <?php endif; ?>

            <?php if(!empty($messages)): ?>
            <div class="alert alert-success">
                <?php foreach($messages as $m) echo "<div>✅ $m</div>"; ?>
            </div>
            <?php endif; ?>

            <?php if($step == 'welcome'): ?>
            <div class="text-center py-3">
                <h4>👋 مرحباً بك في متجر الفاعوري</h4>
                <p class="text-muted">سيقوم هذا المثبت بإعداد المتجر تلقائياً على استضافتك المشتركة.</p>
                <div class="alert alert-info text-start">
                    <strong>📋 قبل البدء تأكد من:</strong>
                    <ul class="mb-0 mt-2">
                        <li>إنشاء قاعدة بيانات MySQL من cPanel</li>
                        <li>معرفة بيانات الدخول (اسم DB, Username, Password)</li>
                        <li>رفع <strong>جميع</strong> ملفات المشروع للاستضافة</li>
                        <li>تأكد أن مجلد <code>storage</code> و <code>bootstrap/cache</code> قابلين للكتابة (chmod 755)</li>
                    </ul>
                </div>
                <a href="?step=check" class="btn btn-lg text-white px-5" style="background: #7b1fa2;">ابدأ التثبيت &rarr;</a>
            </div>

            <?php elseif($step == 'check'):
                $checks = [];
                $checks['PHP >= 8.3'] = version_compare(PHP_VERSION, '8.3.0', '>=');
                $checks['PDO MySQL'] = extension_loaded('pdo_mysql');
                $checks['MBString'] = extension_loaded('mbstring');
                $checks['OpenSSL'] = extension_loaded('openssl');
                $checks['JSON'] = extension_loaded('json');
                $checks['Fileinfo'] = extension_loaded('fileinfo');
                $checks['Tokenizer'] = extension_loaded('tokenizer');
                $checks['XML'] = extension_loaded('xml');
                $checks['Ctype'] = extension_loaded('ctype');
                $checks['BCMath'] = extension_loaded('bcmath');
                $checks['Storage Writable'] = is_writable(__DIR__.'/storage');
                $checks['Bootstrap Cache Writable'] = is_writable(__DIR__.'/bootstrap/cache');
                $checks['Env Writable'] = is_writable(__DIR__) || !file_exists(__DIR__.'/.env');
                $hasVendor = is_dir(__DIR__.'/vendor');
                $hasComposer = file_exists(__DIR__.'/composer.json');
                $allPass = !in_array(false, $checks, true);
            ?>
            <h5>🔍 فحص المتطلبات</h5>
            <table class="table table-bordered table-sm">
                <?php foreach($checks as $name => $pass): ?>
                <tr><td><?= $name ?></td><td class="text-center"><?= $pass ? '<span class="badge bg-success">✅</span>' : '<span class="badge bg-danger">❌</span>' ?></td></tr>
                <?php endforeach; ?>
            </table>

            <div class="alert <?= $hasVendor ? 'alert-success' : 'alert-warning' ?>">
                <strong>📦 مجلد vendor:</strong> <?= $hasVendor ? 'موجود ✅' : 'غير موجود ❌' ?><br>
                <?php if(!$hasVendor): ?>
                <small>يجب تشغيل <code>composer install</code> على جهازك ثم رفع مجلد vendor، أو استخدام خدمة مثل <a href="https://php-download.com/package/laravel/framework" target="_blank">php-download.com</a></small>
                <?php endif; ?>
            </div>

            <?php if($allPass): ?>
            <div class="text-center">
                <a href="?step=env" class="btn btn-success btn-lg">المتطلبات متوفرة &rarr;</a>
            </div>
            <?php else: ?>
            <div class="alert alert-warning">⚠️ بعض المتطلبات غير متوفرة. تواصل مع دعم الاستضافة لتفعيلها.</div>
            <?php endif; ?>

            <?php elseif($step == 'env'):
                if($_SERVER['REQUEST_METHOD'] === 'POST'):
                    $env = file_exists(__DIR__.'/.env.example') ? file_get_contents(__DIR__.'/.env.example') : file_get_contents(__DIR__.'/.env');
                    $env = preg_replace('/APP_KEY=.*/', 'APP_KEY=base64:'.base64_encode(random_bytes(32)), $env);
                    $env = preg_replace('/APP_URL=.*/', 'APP_URL=https://'.$_SERVER['HTTP_HOST'], $env);
                    $env = preg_replace('/DB_DATABASE=.*/', 'DB_DATABASE='.$_POST['db_name'], $env);
                    $env = preg_replace('/DB_USERNAME=.*/', 'DB_USERNAME='.$_POST['db_user'], $env);
                    $env = preg_replace('/DB_PASSWORD=.*/', 'DB_PASSWORD='.$_POST['db_pass'], $env);
                    $env = preg_replace('/ALFAORE_API_TOKEN=.*/', 'ALFAORE_API_TOKEN='.$_POST['api_token'], $env);
                    $env = preg_replace('/ALFAORE_WEBHOOK_SECRET=.*/', 'ALFAORE_WEBHOOK_SECRET='.$_POST['webhook_secret'], $env);

                    if(file_put_contents(__DIR__.'/.env', $env)):
                        msg('تم إنشاء ملف .env بنجاح');
                        header('Location: ?step=db');
                        exit;
                    else:
                        err('فشل إنشاء ملف .env - تأكد من صلاحيات الكتابة');
                    endif;
                endif;
            ?>
            <h5>⚙️ إعدادات المتجر</h5>
            <form method="POST">
                <div class="card mb-3">
                    <div class="card-header bg-light">🗄️ قاعدة البيانات</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label>اسم قاعدة البيانات</label>
                            <input type="text" name="db_name" class="form-control" required placeholder="مثال: alfaore_db">
                        </div>
                        <div class="mb-3">
                            <label>اسم المستخدم</label>
                            <input type="text" name="db_user" class="form-control" required placeholder="مثال: alfaore_user">
                        </div>
                        <div class="mb-3">
                            <label>كلمة المرور</label>
                            <input type="password" name="db_pass" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-header bg-light">🔌 إعدادات Alfaore API</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label>API Token <span class="text-danger">*</span></label>
                            <input type="text" name="api_token" class="form-control" required placeholder="توكن API من Alfaore">
                        </div>
                        <div class="mb-3">
                            <label>Webhook Secret (اختياري)</label>
                            <input type="text" name="webhook_secret" class="form-control" placeholder="للتحقق من Webhooks">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100">حفظ الإعدادات &rarr;</button>
            </form>

            <?php elseif($step == 'db'):
                // Try to import SQL via PDO
                $envFile = __DIR__.'/.env';
                if(!file_exists($envFile)) { err('ملف .env غير موجود. ارجع للخطوة السابقة.'); }
                else {
                    $env = parse_ini_file($envFile);
                    $host = $env['DB_HOST'] ?? 'localhost';
                    $db = $env['DB_DATABASE'] ?? '';
                    $user = $env['DB_USERNAME'] ?? '';
                    $pass = $env['DB_PASSWORD'] ?? '';

                    try {
                        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Select database
                        $pdo->exec("USE `$db`");
                        msg('تم الاتصال بقاعدة البيانات بنجاح');

                        // Import SQL file
                        $sqlFile = __DIR__.'/database.sql';
                        if(!file_exists($sqlFile)) {
                            err('ملف database.sql غير موجود. تأكد من رفعه.');
                        } else {
                            $sql = file_get_contents($sqlFile);
                            // Split by semicolon but be careful with triggers/procedures
                            $pdo->exec($sql);
                            msg('تم استيراد قاعدة البيانات بنجاح!');

                            // Create storage link if possible
                            if(!file_exists(__DIR__.'/public/storage')) {
                                @symlink(__DIR__.'/storage/app/public', __DIR__.'/public/storage');
                                msg('تم إنشاء رابط Storage');
                            }

                            header('Location: ?step=finish');
                            exit;
                        }
                    } catch(PDOException $e) {
                        err('خطأ في الاتصال بقاعدة البيانات: '.$e->getMessage());
                        err('تأكد من صحة بيانات الدخول في ملف .env');
                    }
                }
            ?>
            <div class="log-box">
                <?php foreach($messages as $m) echo htmlspecialchars($m)."\n"; ?>
                <?php foreach($errors as $e) echo "ERROR: ".htmlspecialchars($e)."\n"; ?>
            </div>
            <a href="?step=env" class="btn btn-warning mt-3">رجوع للإعدادات</a>

            <?php elseif($step == 'finish'): ?>
            <div class="text-center py-4">
                <div class="display-1 text-success">🎉</div>
                <h3 class="mt-3">تم التثبيت بنجاح!</h3>
                <p class="text-muted">متجر الفاعوري جاهز للعمل الآن</p>

                <div class="alert alert-info text-start mx-auto" style="max-width: 450px;">
                    <strong>🔑 بيانات الدخول الافتراضية:</strong><br>
                    البريد: <code>admin@alfaore.com</code><br>
                    كلمة المرور: <code>password</code>
                </div>

                <div class="alert alert-warning text-start mx-auto" style="max-width: 450px;">
                    <strong>⚠️ خطوات مهمة بعد التثبيت:</strong>
                    <ol class="mb-0 mt-2">
                        <li><strong>احذف ملف install.php الآن!</strong></li>
                        <li>غيّر كلمة مرور المدير فوراً</li>
                        <li>أضف Cron Job في cPanel:<br>
                            <code style="font-size:0.75rem">* * * * * cd <?= __DIR__ ?> && php artisan schedule:run >> /dev/null 2>&1</code>
                        </li>
                    </ol>
                </div>

                <div class="d-grid gap-2 mx-auto" style="max-width: 300px;">
                    <a href="/" class="btn btn-primary btn-lg">🌐 الذهاب للموقع</a>
                    <a href="/admin" class="btn btn-outline-primary">⚙️ لوحة الإدارة</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
