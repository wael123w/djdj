<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;

class CategoryController extends Controller
{
    public function __construct(
        private CategoryRepositoryInterface $categoryRepo,
        private ProductRepositoryInterface $productRepo,
    ) {}

    public function show(string $slug)
    {
        $category = $this->categoryRepo->findBySlug($slug);
        if (!$category) abort(404);

        $filters = request()->only(['search', 'min_price', 'max_price', 'sort']);
        $products = $this->productRepo->getByCategory($category->id, $filters);

        return view('frontend.categories.show', compact('category', 'products'));
    }
}
