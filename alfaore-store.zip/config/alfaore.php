<?php

return [
    'base_url' => env('ALFAORE_BASE_URL', 'https://api.alfaore-store.com/'),
    'api_token' => env('ALFAORE_API_TOKEN', ''),
    'webhook_secret' => env('ALFAORE_WEBHOOK_SECRET', ''),
    'sync_interval' => env('ALFAORE_SYNC_INTERVAL', 5), // minutes
    'timeout' => 30,
    'retry_times' => 3,
    'retry_sleep' => 2,
];
