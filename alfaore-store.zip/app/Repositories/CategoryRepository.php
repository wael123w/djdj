<?php

namespace App\Repositories;

use App\Models\Category;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Cache;

class CategoryRepository implements CategoryRepositoryInterface
{
    public function getAll(array $filters = []): Collection
    {
        $query = Category::withCount('products');

        if (!empty($filters['parent_id'])) {
            $query->where('parent_id', $filters['parent_id']);
        } elseif (!empty($filters['root_only'])) {
            $query->whereNull('parent_id');
        }
        if (!empty($filters['active'])) {
            $query->where('is_active', true);
        }

        return $query->orderBy('sort_order')->get();
    }

    public function getTree(): Collection
    {
        return Cache::remember('categories.tree', 3600, fn() =>
            Category::with('activeChildren.activeChildren')
                ->whereNull('parent_id')
                ->where('is_active', true)
                ->orderBy('sort_order')
                ->get()
        );
    }

    public function findById(int $id): ?Category
    {
        return Category::with(['parent', 'children', 'products'])->find($id);
    }

    public function findBySlug(string $slug): ?Category
    {
        return Category::with(['children', 'products'])->where('slug', $slug)->first();
    }

    public function create(array $data): Category
    {
        $category = Category::create($data);
        Cache::forget('categories.tree');
        return $category;
    }

    public function update(Category $category, array $data): Category
    {
        $category->update($data);
        Cache::forget('categories.tree');
        return $category->fresh();
    }

    public function delete(Category $category): bool
    {
        Cache::forget('categories.tree');
        return $category->delete();
    }

    public function getHomeCategories(int $limit = 10): Collection
    {
        return Cache::remember('categories.home', 1800, fn() =>
            Category::where('show_on_home', true)
                ->where('is_active', true)
                ->withCount('products')
                ->limit($limit)
                ->get()
        );
    }
}
