@extends('layouts.app')
@section('title', $user->name)
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ $user->name }}</h2>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">{{ __('User Info') }}</div>
                <div class="card-body">
                    <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
                        @csrf @method('PUT')
                        <div class="mb-3"><label class="form-label">{{ __('Name') }}</label><input type="text" name="name" class="form-control" value="{{ $user->name }}"></div>
                        <div class="mb-3"><label class="form-label">{{ __('Email') }}</label><input type="email" name="email" class="form-control" value="{{ $user->email }}"></div>
                        <div class="mb-3"><label class="form-label">{{ __('Role') }}</label>
                            <select name="role" class="form-select">
                                <option value="admin" {{ $user->role->value == 'admin' ? 'selected' : '' }}>{{ __('Admin') }}</option>
                                <option value="user" {{ $user->role->value == 'user' ? 'selected' : '' }}>{{ __('User') }}</option>
                                <option value="vendor" {{ $user->role->value == 'vendor' ? 'selected' : '' }}>{{ __('Vendor') }}</option>
                            </select>
                        </div>
                        <div class="mb-3"><label class="form-label">{{ __('Balance') }}</label><input type="number" step="0.01" name="balance" class="form-control" value="{{ $user->balance }}"></div>
                        <div class="mb-3 form-check"><input type="checkbox" name="is_active" class="form-check-input" value="1" {{ $user->is_active ? 'checked' : '' }}><label class="form-check-label">{{ __('Active') }}</label></div>
                        <button type="submit" class="btn btn-primary-custom">{{ __('Update') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">{{ __('Orders') }}</div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead><tr><th>{{ __('Order') }}</th><th>{{ __('Total') }}</th><th>{{ __('Status') }}</th></tr></thead>
                        <tbody>
                            @foreach($user->orders()->latest()->take(10)->get() as $o)
                            <tr><td>{{ $o->order_number }}</td><td>${{ number_format($o->total, 2) }}</td><td><span class="badge bg-{{ $o->status->color() }}">{{ $o->status->label() }}</span></td></tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
