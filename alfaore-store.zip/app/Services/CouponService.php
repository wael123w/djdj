<?php

namespace App\Services;

use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Order;
use App\Models\User;

class CouponService
{
    public function validate(string $code, float $orderTotal, int $userId): ?Coupon
    {
        $coupon = Coupon::where('code', $code)->first();
        if (!$coupon || !$coupon->isValid()) return null;
        if ($coupon->min_order > 0 && $orderTotal < $coupon->min_order) return null;

        $userUsageCount = CouponUsage::where('coupon_id', $coupon->id)
            ->where('user_id', $userId)->count();
        if ($userUsageCount >= $coupon->usage_per_user) return null;

        return $coupon;
    }

    public function calculateDiscount(Coupon $coupon, float $subtotal): float
    {
        $discount = match ($coupon->type) {
            'percentage' => $subtotal * ($coupon->value / 100),
            default => $coupon->value,
        };
        if ($coupon->max_discount && $discount > $coupon->max_discount) {
            $discount = $coupon->max_discount;
        }
        return round($discount, 4);
    }

    public function recordUsage(Coupon $coupon, User $user, Order $order, float $discount): void
    {
        CouponUsage::create([
            'coupon_id' => $coupon->id,
            'user_id' => $user->id,
            'order_id' => $order->id,
            'discount_amount' => $discount,
        ]);
        $coupon->increment('usage_count');
    }
}
