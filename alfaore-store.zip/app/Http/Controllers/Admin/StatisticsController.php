<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\StatisticsService;

class StatisticsController extends Controller
{
    public function __construct(private StatisticsService $statisticsService) {}

    public function index()
    {
        $stats = $this->statisticsService->getDashboardStats();
        $chartData = $this->statisticsService->getSalesChart(request('period', '30days'));
        return view('admin.statistics.index', compact('stats', 'chartData'));
    }
}
