<?php

namespace App\Models;

use App\Enums\UserRole;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name', 'email', 'password', 'phone', 'avatar', 'role',
        'is_active', 'referral_code', 'referred_by', 'balance',
        'loyalty_points', 'locale', 'currency_code',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'balance' => 'decimal:4',
            'loyalty_points' => 'integer',
            'role' => UserRole::class,
        ];
    }

    public function isAdmin(): bool { return $this->role === UserRole::ADMIN; }
    public function isVendor(): bool { return $this->role === UserRole::VENDOR; }
    public function isUser(): bool { return $this->role === UserRole::USER; }

    public function orders(): HasMany { return $this->hasMany(Order::class); }
    public function cartItems(): HasMany { return $this->hasMany(Cart::class); }
    public function wishlists(): HasMany { return $this->hasMany(Wishlist::class); }
    public function reviews(): HasMany { return $this->hasMany(Review::class); }
    public function activityLogs(): HasMany { return $this->hasMany(ActivityLog::class); }
    public function loyaltyPoints(): HasMany { return $this->hasMany(LoyaltyPoint::class); }
    public function referralsMade(): HasMany { return $this->hasMany(Referral::class, 'referrer_id'); }
    public function referralsReceived(): HasOne { return $this->hasOne(Referral::class, 'referred_id'); }
    public function vendor(): HasOne { return $this->hasOne(Vendor::class); }
    public function referrer(): HasOne { return $this->hasOne(User::class, 'id', 'referred_by'); }
}
