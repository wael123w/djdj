<?php

namespace App\Jobs;

use App\Models\Order;
use App\Services\Alfaore\AlfaoreApiService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessAlfaoreOrderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public Order $order) {}

    public function handle(AlfaoreApiService $api): void
    {
        foreach ($this->order->items as $item) {
            $product = $item->product;
            if (!$product->alfaore_product_id) continue;

            try {
                $params = $item->params ?? [];
                $response = $api->createOrder(
                    $product->alfaore_product_id,
                    $item->quantity,
                    $params
                );

                if (($response['status'] ?? '') === 'OK') {
                    $this->order->update([
                        'alfaore_order_id' => $response['data']['order_id'] ?? null,
                        'alfaore_order_uuid' => $response['data']['order_uuid'] ?? null,
                        'status' => $response['data']['status'] ?? 'wait',
                        'alfaore_response' => $response,
                    ]);
                    $item->update([
                        'alfaore_replay' => $response['data']['replay_api'] ?? null,
                    ]);
                }
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::error('Alfaore order job failed', [
                    'order_id' => $this->order->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
}
