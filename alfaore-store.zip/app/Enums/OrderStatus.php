<?php

namespace App\Enums;

enum OrderStatus: string
{
    case PENDING = 'pending';
    case PROCESSING = 'processing';
    case ACCEPT = 'accept';
    case REJECT = 'reject';
    case WAIT = 'wait';
    case COMPLETED = 'completed';
    case CANCELLED = 'cancelled';
    case REFUNDED = 'refunded';

    public function label(): string
    {
        return match($this) {
            self::PENDING => __('Pending'),
            self::PROCESSING => __('Processing'),
            self::ACCEPT => __('Accepted'),
            self::REJECT => __('Rejected'),
            self::WAIT => __('Waiting'),
            self::COMPLETED => __('Completed'),
            self::CANCELLED => __('Cancelled'),
            self::REFUNDED => __('Refunded'),
        };
    }

    public function color(): string
    {
        return match($this) {
            self::PENDING => 'warning',
            self::PROCESSING => 'info',
            self::ACCEPT => 'success',
            self::REJECT => 'danger',
            self::WAIT => 'secondary',
            self::COMPLETED => 'success',
            self::CANCELLED => 'dark',
            self::REFUNDED => 'primary',
        };
    }
}
