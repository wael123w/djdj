@extends('layouts.app')
@section('title', __('Edit Product'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Edit Product') }}: {{ $product->name }}</h2>
    <div class="card">
        <div class="card-body">
            <form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
                @csrf @method('PUT')
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Name (AR)') }}</label>
                        <input type="text" name="name_ar" class="form-control" value="{{ $product->name_ar }}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Name (EN)') }}</label>
                        <input type="text" name="name_en" class="form-control" value="{{ $product->name_en }}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Slug') }}</label>
                        <input type="text" name="slug" class="form-control" value="{{ $product->slug }}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Category') }}</label>
                        <select name="category_id" class="form-select" required>
                            @foreach($categories as $cat)
                            <option value="{{ $cat->id }}" {{ $product->category_id == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Price') }}</label>
                        <input type="number" step="0.01" name="price" class="form-control" value="{{ $product->price }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Sale Price') }}</label>
                        <input type="number" step="0.01" name="sale_price" class="form-control" value="{{ $product->sale_price }}">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Cost Price') }}</label>
                        <input type="number" step="0.01" name="cost_price" class="form-control" value="{{ $product->cost_price }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Stock') }}</label>
                        <input type="number" name="stock" class="form-control" value="{{ $product->stock }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Min Qty') }}</label>
                        <input type="number" name="min_qty" class="form-control" value="{{ $product->min_qty }}" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Max Qty') }}</label>
                        <input type="number" name="max_qty" class="form-control" value="{{ $product->max_qty }}" required>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">{{ __('Image') }}</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                        @if($product->image)
                        <img src="{{ asset('storage/' . $product->image) }}" class="mt-2 rounded" style="height:80px;">
                        @endif
                    </div>
                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="is_active" class="form-check-input" id="is_active" value="1" {{ $product->is_active ? 'checked' : '' }}>
                            <label class="form-check-label" for="is_active">{{ __('Active') }}</label>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" name="is_featured" class="form-check-input" id="is_featured" value="1" {{ $product->is_featured ? 'checked' : '' }}>
                            <label class="form-check-label" for="is_featured">{{ __('Featured') }}</label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary-custom">{{ __('Update') }}</button>
                <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
            </form>
        </div>
    </div>
</div>
@endsection
