@extends('layouts.app')
@section('title', __('Order') . ' #' . $order->order_number)
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Order') }} #{{ $order->order_number }}</h2>
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-3">
                <div class="card-header">{{ __('Order Details') }}</div>
                <div class="card-body">
                    <table class="table">
                        <tr><th>{{ __('Customer') }}</th><td>{{ $order->user?->name }} ({{ $order->user?->email }})</td></tr>
                        <tr><th>{{ __('Status') }}</th><td><span class="badge bg-{{ $order->status->color() }}">{{ $order->status->label() }}</span></td></tr>
                        <tr><th>{{ __('Payment Status') }}</th><td>{{ $order->payment_status->label() }}</td></tr>
                        <tr><th>{{ __('Subtotal') }}</th><td>${{ number_format($order->subtotal, 2) }}</td></tr>
                        <tr><th>{{ __('Discount') }}</th><td>${{ number_format($order->discount, 2) }}</td></tr>
                        <tr><th>{{ __('Total') }}</th><td class="fw-bold text-primary">${{ number_format($order->total, 2) }}</td></tr>
                        <tr><th>{{ __('Profit') }}</th><td>${{ number_format($order->profit, 2) }}</td></tr>
                        <tr><th>{{ __('Date') }}</th><td>{{ $order->created_at->format('Y-m-d H:i:s') }}</td></tr>
                        @if($order->alfaore_order_id)
                        <tr><th>{{ __('Alfaore Order ID') }}</th><td>{{ $order->alfaore_order_id }}</td></tr>
                        @endif
                    </table>
                </div>
            </div>
            <div class="card">
                <div class="card-header">{{ __('Items') }}</div>
                <div class="card-body">
                    <table class="table">
                        <thead><tr><th>{{ __('Product') }}</th><th>{{ __('Price') }}</th><th>{{ __('Qty') }}</th><th>{{ __('Subtotal') }}</th></tr></thead>
                        <tbody>
                            @foreach($order->items as $item)
                            <tr>
                                <td>{{ $item->product_name }}</td>
                                <td>${{ number_format($item->price, 2) }}</td>
                                <td>{{ $item->quantity }}</td>
                                <td>${{ number_format($item->subtotal, 2) }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">{{ __('Update Status') }}</div>
                <div class="card-body">
                    <form action="{{ route('admin.orders.status', $order->id) }}" method="POST">
                        @csrf
                        <select name="status" class="form-select mb-2">
                            <option value="pending" {{ $order->status->value == 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                            <option value="processing" {{ $order->status->value == 'processing' ? 'selected' : '' }}>{{ __('Processing') }}</option>
                            <option value="accept" {{ $order->status->value == 'accept' ? 'selected' : '' }}>{{ __('Accepted') }}</option>
                            <option value="completed" {{ $order->status->value == 'completed' ? 'selected' : '' }}>{{ __('Completed') }}</option>
                            <option value="cancelled" {{ $order->status->value == 'cancelled' ? 'selected' : '' }}>{{ __('Cancelled') }}</option>
                            <option value="refunded" {{ $order->status->value == 'refunded' ? 'selected' : '' }}>{{ __('Refunded') }}</option>
                        </select>
                        <button type="submit" class="btn btn-primary-custom w-100">{{ __('Update') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
