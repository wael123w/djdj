<?php

namespace App\Providers;

use App\Events\OrderCreated;
use App\Events\OrderStatusUpdated;
use App\Events\UserRegistered;
use App\Listeners\LogOrderActivity;
use App\Listeners\ProcessReferral;
use App\Listeners\SendOrderNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        OrderCreated::class => [
            SendOrderNotification::class,
            LogOrderActivity::class,
        ],
        OrderStatusUpdated::class => [
            SendOrderNotification::class,
            LogOrderActivity::class,
        ],
        UserRegistered::class => [
            ProcessReferral::class,
        ],
    ];

    public function boot(): void
    {
        parent::boot();
    }
}
