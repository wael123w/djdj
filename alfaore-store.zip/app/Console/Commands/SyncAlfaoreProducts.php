<?php

namespace App\Console\Commands;

use App\Jobs\SyncAlfaoreProductsJob;
use Illuminate\Console\Command;

class SyncAlfaoreProducts extends Command
{
    protected $signature = 'alfaore:sync-products';
    protected $description = 'Sync products from Alfaore API';

    public function handle(): void
    {
        $this->info('Starting Alfaore product sync...');
        SyncAlfaoreProductsJob::dispatchSync();
        $this->info('Sync completed!');
    }
}
