@extends('layouts.app')
@section('title', __('Settings'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Settings') }}</h2>
    <form action="{{ route('admin.settings.update') }}" method="POST">
        @csrf
        @foreach($settings as $group => $items)
        <div class="card mb-4">
            <div class="card-header text-capitalize">{{ $group }}</div>
            <div class="card-body">
                <div class="row">
                    @foreach($items as $s)
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ ucfirst(str_replace('_', ' ', $s->key)) }}</label>
                        @if($s->type == 'boolean')
                        <select name="{{ $s->key }}" class="form-select">
                            <option value="1" {{ $s->value == '1' ? 'selected' : '' }}>{{ __('Yes') }}</option>
                            <option value="0" {{ $s->value == '0' ? 'selected' : '' }}>{{ __('No') }}</option>
                        </select>
                        @else
                        <input type="text" name="{{ $s->key }}" class="form-control" value="{{ $s->value }}">
                        @endif
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endforeach
        <button type="submit" class="btn btn-primary-custom btn-lg">{{ __('Save Settings') }}</button>
    </form>
</div>
@endsection
