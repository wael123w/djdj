<?php

namespace App\Listeners;

use App\Events\UserRegistered;
use App\Services\ReferralService;

class ProcessReferral
{
    public function __construct(private ReferralService $referralService) {}

    public function handle(UserRegistered $event): void
    {
        $this->referralService->processReferral($event->user, $event->referralCode);
    }
}
