<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;

class HomeController extends Controller
{
    public function __construct(
        private CategoryRepositoryInterface $categoryRepo,
        private ProductRepositoryInterface $productRepo,
    ) {}

    public function index()
    {
        $categories = $this->categoryRepo->getHomeCategories();
        $featuredProducts = $this->productRepo->getFeatured(12);

        return view('frontend.home.index', compact('categories', 'featuredProducts'));
    }
}
