@extends('layouts.app')
@section('title', __('Coupons'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Coupons') }}</h2>
    <div class="card mb-4">
        <div class="card-header">{{ __('Add Coupon') }}</div>
        <div class="card-body">
            <form action="{{ route('admin.coupons.store') }}" method="POST">
                @csrf
                <div class="row g-2">
                    <div class="col-md-2"><input type="text" name="code" class="form-control" placeholder="{{ __('Code') }}" required></div>
                    <div class="col-md-2">
                        <select name="type" class="form-select" required>
                            <option value="percentage">%</option>
                            <option value="fixed">$</option>
                        </select>
                    </div>
                    <div class="col-md-2"><input type="number" step="0.01" name="value" class="form-control" placeholder="{{ __('Value') }}" required></div>
                    <div class="col-md-2"><input type="number" step="0.01" name="min_order" class="form-control" placeholder="{{ __('Min Order') }}"></div>
                    <div class="col-md-2"><input type="datetime-local" name="expires_at" class="form-control"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-primary-custom w-100">{{ __('Add') }}</button></div>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark"><tr><th>{{ __('Code') }}</th><th>{{ __('Type') }}</th><th>{{ __('Value') }}</th><th>{{ __('Used') }}</th><th>{{ __('Status') }}</th><th>{{ __('Actions') }}</th></tr></thead>
                    <tbody>
                        @foreach($coupons as $c)
                        <tr>
                            <td><code>{{ $c->code }}</code></td>
                            <td>{{ $c->type }}</td>
                            <td>{{ $c->type == 'percentage' ? $c->value . '%' : '$' . $c->value }}</td>
                            <td>{{ $c->usage_count }}/{{ $c->usage_limit ?? '∞' }}</td>
                            <td><span class="badge bg-{{ $c->isValid() ? 'success' : 'danger' }}">{{ $c->isValid() ? __('Active') : __('Inactive') }}</span></td>
                            <td>
                                <form action="{{ route('admin.coupons.destroy', $c->id) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Are you sure?') }}')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $coupons->links() }}
        </div>
    </div>
</div>
@endsection
