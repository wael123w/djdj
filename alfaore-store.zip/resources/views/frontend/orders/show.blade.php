@extends('layouts.app')
@section('title', __('Order') . ' #' . $order->order_number)
@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary-custom text-white d-flex justify-content-between">
                    <span>{{ __('Order') }} #{{ $order->order_number }}</span>
                    <span class="badge bg-{{ $order->status->color() }}">{{ $order->status->label() }}</span>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-6"><strong>{{ __('Date') }}:</strong> {{ $order->created_at->format('Y-m-d H:i') }}</div>
                        <div class="col-6"><strong>{{ __('Total') }}:</strong> <span class="text-primary fw-bold">${{ number_format($order->total, 2) }}</span></div>
                    </div>
                    <hr>
                    <h6>{{ __('Items') }}</h6>
                    @foreach($order->items as $item)
                    <div class="d-flex justify-content-between py-2 border-bottom">
                        <div>{{ $item->product_name }} x{{ $item->quantity }}</div>
                        <div>${{ number_format($item->subtotal, 2) }}</div>
                    </div>
                    @endforeach
                    <div class="d-flex justify-content-between mt-3 fw-bold">
                        <div>{{ __('Total') }}</div>
                        <div class="text-primary">${{ number_format($order->total, 2) }}</div>
                    </div>
                    @if(in_array($order->status->value, ['pending', 'wait']))
                    <form action="{{ route('orders.cancel', $order->id) }}" method="POST" class="mt-3">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger w-100">{{ __('Cancel Order') }}</button>
                    </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
