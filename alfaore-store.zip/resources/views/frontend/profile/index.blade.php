@extends('layouts.app')
@section('title', __('My Profile'))
@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-body text-center">
                    <i class="bi bi-person-circle display-1 text-primary"></i>
                    <h5 class="mt-2">{{ $user->name }}</h5>
                    <p class="text-muted">{{ $user->email }}</p>
                    <p><span class="badge bg-primary">{{ __('Balance') }}: ${{ number_format($user->balance, 2) }}</span></p>
                    <p><span class="badge bg-warning">{{ __('Points') }}: {{ $user->loyalty_points }}</span></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header">{{ __('Referral Stats') }}</div>
                <div class="card-body">
                    <p>{{ __('Total Referrals') }}: <strong>{{ $referralStats['total_referrals'] }}</strong></p>
                    <p>{{ __('Paid') }}: <strong>{{ $referralStats['paid'] }}</strong></p>
                    <p>{{ __('Commission') }}: <strong>${{ number_format($referralStats['total_commission'], 2) }}</strong></p>
                    <div class="input-group">
                        <input type="text" class="form-control" value="{{ url('/register?ref=' . $user->referral_code) }}" readonly id="refLink">
                        <button class="btn btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('refLink').value)">{{ __('Copy') }}</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card mb-3">
                <div class="card-header">{{ __('Edit Profile') }}</div>
                <div class="card-body">
                    <form action="{{ route('profile.update') }}" method="POST">
                        @csrf @method('PUT')
                        <div class="mb-3"><label class="form-label">{{ __('Name') }}</label><input type="text" name="name" class="form-control" value="{{ $user->name }}"></div>
                        <div class="mb-3"><label class="form-label">{{ __('Phone') }}</label><input type="text" name="phone" class="form-control" value="{{ $user->phone }}"></div>
                        <div class="mb-3"><label class="form-label">{{ __('Language') }}</label>
                            <select name="locale" class="form-select">
                                <option value="ar" {{ $user->locale == 'ar' ? 'selected' : '' }}>العربية</option>
                                <option value="en" {{ $user->locale == 'en' ? 'selected' : '' }}>English</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary-custom">{{ __('Save') }}</button>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-header">{{ __('Recent Orders') }}</div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead><tr><th>{{ __('Order') }}</th><th>{{ __('Total') }}</th><th>{{ __('Status') }}</th></tr></thead>
                        <tbody>
                            @foreach($orders as $o)
                            <tr><td><a href="{{ route('orders.show', $o->id) }}">{{ $o->order_number }}</a></td><td>${{ number_format($o->total, 2) }}</td><td><span class="badge bg-{{ $o->status->color() }}">{{ $o->status->label() }}</span></td></tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
