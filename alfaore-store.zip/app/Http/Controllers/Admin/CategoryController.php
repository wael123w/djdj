<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreCategoryRequest;
use App\Repositories\Contracts\CategoryRepositoryInterface;

class CategoryController extends Controller
{
    public function __construct(private CategoryRepositoryInterface $categoryRepo) {}

    public function index()
    {
        $categories = $this->categoryRepo->getAll(['root_only' => true]);
        return view('admin.categories.index', compact('categories'));
    }

    public function store(StoreCategoryRequest $request)
    {
        $data = $request->validated();
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('categories', 'public');
        }
        $this->categoryRepo->create($data);
        return back()->with('success', __('Category created'));
    }

    public function update(StoreCategoryRequest $request, int $id)
    {
        $category = $this->categoryRepo->findById($id);
        $data = $request->validated();
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('categories', 'public');
        }
        $this->categoryRepo->update($category, $data);
        return back()->with('success', __('Category updated'));
    }

    public function destroy(int $id)
    {
        $category = $this->categoryRepo->findById($id);
        $this->categoryRepo->delete($category);
        return back()->with('success', __('Category deleted'));
    }
}
