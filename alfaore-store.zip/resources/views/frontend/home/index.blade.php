@extends('layouts.app')
@section('title', __('Home'))
@section('content')
<div class="bg-primary-custom text-white py-5">
    <div class="container text-center">
        <h1 class="display-5 fw-bold">{{ __('Welcome to') }} {{ config('settings.site_name') }}</h1>
        <p class="lead">{{ __('Your one-stop digital store') }}</p>
        <a href="{{ route('products.index') }}" class="btn btn-light btn-lg mt-3">{{ __('Browse Products') }}</a>
    </div>
</div>

<div class="container py-5">
    <h2 class="mb-4">{{ __('Categories') }}</h2>
    <div class="row g-4">
        @foreach($categories as $category)
        <div class="col-6 col-md-4 col-lg-3">
            <a href="{{ route('categories.show', $category->slug) }}" class="text-decoration-none">
                <div class="card category-card h-100 text-center p-3 card-hover">
                    <div class="card-body">
                        <i class="bi bi-grid-3x3-gap-fill display-4 text-primary"></i>
                        <h5 class="card-title mt-3 text-dark">{{ $category->name }}</h5>
                        <span class="badge bg-secondary">{{ $category->products_count }} {{ __('Products') }}</span>
                    </div>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>

<div class="container py-5">
    <h2 class="mb-4">{{ __('Featured Products') }}</h2>
    <div class="row g-4">
        @foreach($featuredProducts as $product)
        <div class="col-6 col-md-4 col-lg-3">
            @include('components.product-card', ['product' => $product])
        </div>
        @endforeach
    </div>
</div>
@endsection
