<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreCouponRequest;
use App\Models\Coupon;

class CouponController extends Controller
{
    public function index()
    {
        $coupons = Coupon::latest()->paginate(25);
        return view('admin.coupons.index', compact('coupons'));
    }

    public function store(StoreCouponRequest $request)
    {
        Coupon::create($request->validated());
        return back()->with('success', __('Coupon created'));
    }

    public function update(StoreCouponRequest $request, int $id)
    {
        $coupon = Coupon::findOrFail($id);
        $coupon->update($request->validated());
        return back()->with('success', __('Coupon updated'));
    }

    public function destroy(int $id)
    {
        Coupon::destroy($id);
        return back()->with('success', __('Coupon deleted'));
    }
}
