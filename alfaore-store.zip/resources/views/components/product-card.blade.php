<div class="card product-card h-100">
    <a href="{{ route('products.show', $product->slug) }}">
        <img src="{{ $product->image ? asset('storage/' . $product->image) : 'https://via.placeholder.com/300x200?text=' . urlencode($product->name) }}" class="card-img-top" alt="{{ $product->name }}" style="height:180px;object-fit:cover;">
    </a>
    <div class="card-body d-flex flex-column">
        <h6 class="card-title">{{ $product->name }}</h6>
        <div class="mt-auto">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fw-bold text-primary">${{ number_format($product->final_price, 2) }}</span>
                @if($product->sale_price)
                <small class="text-decoration-line-through text-muted">${{ number_format($product->price, 2) }}</small>
                @endif
            </div>
            <form action="{{ route('cart.store') }}" method="POST" class="mt-2">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                <input type="hidden" name="quantity" value="1">
                <button type="submit" class="btn btn-primary-custom btn-sm w-100">{{ __('Add to Cart') }}</button>
            </form>
        </div>
    </div>
</div>
