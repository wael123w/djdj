<?php

namespace Database\Seeders;

use App\Models\Currency;
use Illuminate\Database\Seeder;

class CurrencySeeder extends Seeder
{
    public function run(): void
    {
        Currency::create([
            'code' => 'USD',
            'name_ar' => 'دولار أمريكي',
            'name_en' => 'US Dollar',
            'symbol' => '$',
            'exchange_rate' => 1.000000,
            'is_default' => true,
            'is_active' => true,
            'sort_order' => 1,
        ]);

        Currency::create([
            'code' => 'EUR',
            'name_ar' => 'يورو',
            'name_en' => 'Euro',
            'symbol' => '€',
            'exchange_rate' => 0.920000,
            'is_default' => false,
            'is_active' => true,
            'sort_order' => 2,
        ]);

        Currency::create([
            'code' => 'SAR',
            'name_ar' => 'ريال سعودي',
            'name_en' => 'Saudi Riyal',
            'symbol' => '﷼',
            'exchange_rate' => 3.750000,
            'is_default' => false,
            'is_active' => true,
            'sort_order' => 3,
        ]);
    }
}
