<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderStatusNotification extends Notification
{
    use Queueable;

    public function __construct(public array $data) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject(__('Order Update') . ' #' . $this->data['order_number'])
            ->line(__('Your order status has been updated.'))
            ->line(__('Order Number:') . ' ' . $this->data['order_number'])
            ->line(__('Status:') . ' ' . $this->data['status'])
            ->action(__('View Order'), url('/orders/' . $this->data['order_id']));
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'order_status',
            'order_id' => $this->data['order_id'],
            'order_number' => $this->data['order_number'],
            'status' => $this->data['status'],
            'total' => $this->data['total'] ?? null,
        ];
    }
}
