<?php

namespace Database\Seeders;

use App\Models\Language;
use Illuminate\Database\Seeder;

class LanguageSeeder extends Seeder
{
    public function run(): void
    {
        Language::create([
            'code' => 'ar',
            'name' => 'Arabic',
            'native_name' => 'العربية',
            'flag' => '🇸🇦',
            'is_default' => true,
            'is_active' => true,
            'is_rtl' => true,
            'sort_order' => 1,
        ]);

        Language::create([
            'code' => 'en',
            'name' => 'English',
            'native_name' => 'English',
            'flag' => '🇬🇧',
            'is_default' => false,
            'is_active' => true,
            'is_rtl' => false,
            'sort_order' => 2,
        ]);
    }
}
