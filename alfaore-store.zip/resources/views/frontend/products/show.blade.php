@extends('layouts.app')
@section('title', $product->name)
@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-md-5">
            <img src="{{ $product->image ? asset('storage/' . $product->image) : 'https://via.placeholder.com/500x400?text=' . urlencode($product->name) }}" class="img-fluid rounded" alt="{{ $product->name }}">
        </div>
        <div class="col-md-7">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('categories.show', $product->category->slug) }}">{{ $product->category->name }}</a></li>
                    <li class="breadcrumb-item active">{{ $product->name }}</li>
                </ol>
            </nav>
            <h2>{{ $product->name }}</h2>
            <div class="mb-3">
                @for($i = 1; $i <= 5; $i++)
                <i class="bi bi-star{{ $i <= $product->rating ? '-fill' : '' }} text-warning"></i>
                @endfor
                <span class="text-muted">({{ $product->reviews_count }} {{ __('reviews') }})</span>
            </div>
            <h3 class="text-primary">${{ number_format($product->final_price, 2) }}</h3>
            @if($product->sale_price)
            <small class="text-decoration-line-through text-muted">${{ number_format($product->price, 2) }}</small>
            @endif
            <p class="mt-3">{{ $product->description }}</p>
            <form action="{{ route('cart.store') }}" method="POST" class="mt-4">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                <div class="row g-2 align-items-center">
                    <div class="col-auto">
                        <input type="number" name="quantity" value="1" min="{{ $product->min_qty }}" max="{{ $product->max_qty }}" class="form-control" style="width:80px;">
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary-custom btn-lg w-100">{{ __('Add to Cart') }}</button>
                    </div>
                </div>
            </form>
            <div class="mt-3">
                <a href="{{ route('wishlist.store', $product->id) }}" class="btn btn-outline-danger"><i class="bi bi-heart"></i> {{ __('Add to Wishlist') }}</a>
            </div>
        </div>
    </div>
</div>
@endsection
