<?php

namespace App\Services;

use App\Models\User;

class NotificationService
{
    public function notifyUser(User $user, string $type, array $data): void
    {
        $notificationClass = match ($type) {
            'order_created' => \App\Notifications\OrderStatusNotification::class,
            'order_updated' => \App\Notifications\OrderStatusNotification::class,
            default => \App\Notifications\NewOrderNotification::class,
        };
        $user->notify(new $notificationClass($data));
    }

    public function notifyAdmins(string $type, array $data): void
    {
        $admins = User::where('role', 'admin')->get();
        foreach ($admins as $admin) {
            $this->notifyUser($admin, $type, $data);
        }
    }
}
