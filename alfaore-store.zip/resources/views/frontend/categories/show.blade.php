@extends('layouts.app')
@section('title', $category->name)
@section('content')
<div class="container py-5">
    <h2 class="mb-4">{{ $category->name }}</h2>
    <div class="row g-4">
        @forelse($products as $product)
        <div class="col-6 col-md-4 col-lg-3">
            @include('components.product-card', ['product' => $product])
        </div>
        @empty
        <div class="col-12 text-center py-5"><p class="text-muted">{{ __('No products in this category') }}</p></div>
        @endforelse
    </div>
    <div class="mt-4">{{ $products->links() }}</div>
</div>
@endsection
