<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Services\ReferralService;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function __construct(private ReferralService $referralService) {}

    public function index()
    {
        $user = auth()->user();
        $referralStats = $this->referralService->getReferralStats($user);
        $orders = $user->orders()->latest()->take(5)->get();
        $notifications = $user->notifications()->latest()->take(10)->get();

        return view('frontend.profile.index', compact('user', 'referralStats', 'orders', 'notifications'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'locale' => 'required|in:ar,en',
        ]);

        auth()->user()->update($data);
        return back()->with('success', __('Profile updated'));
    }
}
