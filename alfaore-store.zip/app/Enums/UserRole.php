<?php

namespace App\Enums;

enum UserRole: string
{
    case ADMIN = 'admin';
    case USER = 'user';
    case VENDOR = 'vendor';

    public function label(): string
    {
        return match($this) {
            self::ADMIN => __('Administrator'),
            self::USER => __('Customer'),
            self::VENDOR => __('Vendor'),
        };
    }
}
