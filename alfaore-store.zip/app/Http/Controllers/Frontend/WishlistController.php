<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Wishlist;

class WishlistController extends Controller
{
    public function index()
    {
        $items = Wishlist::with('product')->where('user_id', auth()->id())->paginate(24);
        return view('frontend.wishlist.index', compact('items'));
    }

    public function store(int $productId)
    {
        Wishlist::firstOrCreate([
            'user_id' => auth()->id(),
            'product_id' => $productId,
        ]);
        return back()->with('success', __('Added to wishlist'));
    }

    public function destroy(int $id)
    {
        Wishlist::where('id', $id)->where('user_id', auth()->id())->delete();
        return back()->with('success', __('Removed from wishlist'));
    }
}
