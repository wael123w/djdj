<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Coupon extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code', 'name_ar', 'name_en', 'type', 'value', 'min_order', 'max_discount',
        'usage_limit', 'usage_count', 'usage_per_user', 'starts_at', 'expires_at',
        'is_active', 'applicable_categories', 'applicable_products',
    ];

    protected function casts(): array
    {
        return [
            'value' => 'decimal:4',
            'min_order' => 'decimal:4',
            'max_discount' => 'decimal:4',
            'usage_limit' => 'integer',
            'usage_count' => 'integer',
            'usage_per_user' => 'integer',
            'starts_at' => 'datetime',
            'expires_at' => 'datetime',
            'is_active' => 'boolean',
            'applicable_categories' => 'array',
            'applicable_products' => 'array',
        ];
    }

    public function usages(): HasMany { return $this->hasMany(CouponUsage::class); }

    public function isValid(): bool
    {
        if (!$this->is_active) return false;
        if ($this->starts_at && now()->lt($this->starts_at)) return false;
        if ($this->expires_at && now()->gt($this->expires_at)) return false;
        if ($this->usage_limit && $this->usage_count >= $this->usage_limit) return false;
        return true;
    }
}
