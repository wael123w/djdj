<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    use HasFactory;

    protected $fillable = [
        'code', 'name', 'native_name', 'flag', 'is_default', 'is_active', 'is_rtl', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'is_default' => 'boolean',
            'is_active' => 'boolean',
            'is_rtl' => 'boolean',
            'sort_order' => 'integer',
        ];
    }

    public function scopeActive($query) { return $query->where('is_active', true); }
    public function scopeDefault($query) { return $query->where('is_default', true); }
}
