<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name_ar' => 'الرصيد', 'name_en' => 'Balance', 'slug' => 'balance', 'show_on_home' => true, 'sort_order' => 1],
            ['name_ar' => 'الألعاب', 'name_en' => 'Games', 'slug' => 'games', 'show_on_home' => true, 'sort_order' => 2],
            ['name_ar' => 'الدردشة', 'name_en' => 'Chat', 'slug' => 'chat', 'show_on_home' => true, 'sort_order' => 3],
            ['name_ar' => 'الأرقام والحسابات', 'name_en' => 'Numbers & Accounts', 'slug' => 'numbers-accounts', 'show_on_home' => true, 'sort_order' => 4],
            ['name_ar' => 'العملات الرقمية', 'name_en' => 'Digital Currency', 'slug' => 'digital-currency', 'show_on_home' => true, 'sort_order' => 5],
            ['name_ar' => 'البطاقات الإلكترونية', 'name_en' => 'E-Cards', 'slug' => 'e-cards', 'show_on_home' => true, 'sort_order' => 6],
            ['name_ar' => 'الحوالات المالية', 'name_en' => 'Money Transfers', 'slug' => 'money-transfers', 'show_on_home' => true, 'sort_order' => 7],
            ['name_ar' => 'السوشيال ميديا', 'name_en' => 'Social Media', 'slug' => 'social-media', 'show_on_home' => true, 'sort_order' => 8],
            ['name_ar' => 'الاشتراكات', 'name_en' => 'Subscriptions', 'slug' => 'subscriptions', 'show_on_home' => true, 'sort_order' => 9],
        ];

        foreach ($categories as $cat) {
            Category::create($cat);
        }
    }
}
