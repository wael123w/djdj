<?php

namespace App\Repositories;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class OrderRepository implements OrderRepositoryInterface
{
    public function getAll(array $filters = [], int $perPage = 15): LengthAwarePaginator
    {
        $query = Order::with(['user', 'items.product']);

        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (!empty($filters['payment_status'])) {
            $query->where('payment_status', $filters['payment_status']);
        }
        if (!empty($filters['user_id'])) {
            $query->where('user_id', $filters['user_id']);
        }
        if (!empty($filters['date_from'])) {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }
        if (!empty($filters['search'])) {
            $query->where('order_number', 'like', "%{$filters['search']}%");
        }

        return $query->latest()->paginate($perPage);
    }

    public function findById(int $id): ?Order
    {
        return Order::with(['user', 'items.product', 'coupon'])->find($id);
    }

    public function findByOrderNumber(string $orderNumber): ?Order
    {
        return Order::with(['user', 'items.product'])->where('order_number', $orderNumber)->first();
    }

    public function findByAlfaoreId(string $alfaoreId): ?Order
    {
        return Order::where('alfaore_order_id', $alfaoreId)->first();
    }

    public function create(array $data): Order
    {
        return Order::create($data);
    }

    public function update(Order $order, array $data): Order
    {
        $order->update($data);
        return $order->fresh();
    }

    public function getUserOrders(int $userId, array $filters = []): LengthAwarePaginator
    {
        $filters['user_id'] = $userId;
        return $this->getAll($filters);
    }

    public function getTodayStats(): array
    {
        return [
            'total' => Order::today()->count(),
            'pending' => Order::today()->pending()->count(),
            'completed' => Order::today()->completed()->count(),
            'cancelled' => Order::today()->cancelled()->count(),
            'revenue' => Order::today()->paid()->sum('total') ?? 0,
            'profit' => Order::today()->paid()->sum('profit') ?? 0,
        ];
    }

    public function getStatistics(string $period = 'today'): array
    {
        $query = match ($period) {
            'today' => Order::today(),
            'week' => Order::whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]),
            'month' => Order::whereMonth('created_at', now()->month)->whereYear('created_at', now()->year),
            'year' => Order::whereYear('created_at', now()->year),
            default => Order::query(),
        };

        return [
            'total_orders' => (clone $query)->count(),
            'total_revenue' => (clone $query)->paid()->sum('total') ?? 0,
            'total_profit' => (clone $query)->paid()->sum('profit') ?? 0,
            'successful' => (clone $query)->where('status', OrderStatus::ACCEPT)->count(),
            'pending_count' => (clone $query)->pending()->count(),
            'cancelled_count' => (clone $query)->cancelled()->count(),
        ];
    }
}
