<?php

namespace App\Listeners;

use App\Events\OrderCreated;
use App\Events\OrderStatusUpdated;
use App\Services\ActivityLogService;

class LogOrderActivity
{
    public function __construct(private ActivityLogService $activityLogService) {}

    public function handle(OrderCreated|OrderStatusUpdated $event): void
    {
        $order = $event->order;
        $type = $event instanceof OrderCreated ? 'order_created' : 'order_status_updated';

        $this->activityLogService->log(
            $order->user_id,
            $type,
            $event instanceof OrderCreated
                ? "تم إنشاء طلب جديد #{$order->order_number}"
                : "تم تحديث حالة الطلب #{$order->order_number} إلى {$order->status->label()}",
            $event instanceof OrderCreated
                ? "New order created #{$order->order_number}"
                : "Order #{$order->order_number} status updated to {$order->status->label()}",
            $order
        );
    }
}
