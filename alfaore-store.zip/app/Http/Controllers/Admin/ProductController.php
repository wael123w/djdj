<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreProductRequest;
use App\Http\Requests\Admin\UpdateProductRequest;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;

class ProductController extends Controller
{
    public function __construct(
        private ProductRepositoryInterface $productRepo,
        private CategoryRepositoryInterface $categoryRepo,
    ) {}

    public function index()
    {
        $products = $this->productRepo->getAll(request()->only(['search', 'category_id']), 25);
        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        $categories = $this->categoryRepo->getAll();
        return view('admin.products.create', compact('categories'));
    }

    public function store(StoreProductRequest $request)
    {
        $data = $request->validated();
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }
        $this->productRepo->create($data);
        return redirect()->route('admin.products.index')->with('success', __('Product created'));
    }

    public function edit(int $id)
    {
        $product = $this->productRepo->findById($id);
        $categories = $this->categoryRepo->getAll();
        return view('admin.products.edit', compact('product', 'categories'));
    }

    public function update(UpdateProductRequest $request, int $id)
    {
        $product = $this->productRepo->findById($id);
        $data = $request->validated();
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }
        $this->productRepo->update($product, $data);
        return redirect()->route('admin.products.index')->with('success', __('Product updated'));
    }

    public function destroy(int $id)
    {
        $product = $this->productRepo->findById($id);
        $this->productRepo->delete($product);
        return back()->with('success', __('Product deleted'));
    }
}
