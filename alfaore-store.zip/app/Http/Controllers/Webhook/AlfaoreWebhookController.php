<?php

namespace App\Http\Controllers\Webhook;

use App\Http\Controllers\Controller;
use App\Services\Alfaore\AlfaoreWebhookService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AlfaoreWebhookController extends Controller
{
    public function __construct(private AlfaoreWebhookService $webhookService) {}

    public function handle(Request $request)
    {
        $payload = $request->all();
        $signature = $request->header('X-Alfaore-Signature', '');

        if (!$this->webhookService->verifySignature(json_encode($payload), $signature)) {
            Log::warning('Invalid Alfaore webhook signature');
            return response()->json(['error' => 'Invalid signature'], 401);
        }

        $this->webhookService->handle($payload);

        return response()->json(['status' => 'OK']);
    }
}
