@extends('layouts.app')
@section('title', __('Wishlist'))
@section('content')
<div class="container py-5">
    <h2 class="mb-4">{{ __('My Wishlist') }}</h2>
    <div class="row g-4">
        @forelse($items as $item)
        <div class="col-6 col-md-4 col-lg-3">
            @include('components.product-card', ['product' => $item->product])
            <form action="{{ route('wishlist.destroy', $item->id) }}" method="POST" class="mt-2">
                @csrf @method('DELETE')
                <button type="submit" class="btn btn-outline-danger btn-sm w-100">{{ __('Remove') }}</button>
            </form>
        </div>
        @empty
        <div class="col-12 text-center py-5"><i class="bi bi-heart display-1 text-muted"></i><p class="mt-3">{{ __('Your wishlist is empty') }}</p></div>
        @endforelse
    </div>
    <div class="mt-4">{{ $items->links() }}</div>
</div>
@endsection
