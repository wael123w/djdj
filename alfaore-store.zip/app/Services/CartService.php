<?php

namespace App\Services;

use App\Models\Cart;
use Illuminate\Database\Eloquent\Collection;

class CartService
{
    public function getCartItems(int $userId): Collection
    {
        return Cart::with('product')->where('user_id', $userId)->get();
    }

    public function addToCart(int $userId, int $productId, int $quantity = 1, array $params = []): Cart
    {
        $cart = Cart::where('user_id', $userId)->where('product_id', $productId)->first();

        if ($cart) {
            $cart->update([
                'quantity' => $cart->quantity + $quantity,
                'params' => array_merge($cart->params ?? [], $params),
            ]);
            return $cart->fresh();
        }

        return Cart::create([
            'user_id' => $userId,
            'product_id' => $productId,
            'quantity' => $quantity,
            'params' => $params,
        ]);
    }

    public function updateCartItem(int $cartId, int $quantity, array $params = []): Cart
    {
        $cart = Cart::findOrFail($cartId);
        $cart->update([
            'quantity' => max(1, $quantity),
            'params' => array_merge($cart->params ?? [], $params),
        ]);
        return $cart->fresh();
    }

    public function removeFromCart(int $cartId): void
    {
        Cart::destroy($cartId);
    }

    public function clearCart(int $userId): void
    {
        Cart::where('user_id', $userId)->delete();
    }

    public function getCartTotal(int $userId): float
    {
        return Cart::where('user_id', $userId)
            ->with('product')
            ->get()
            ->sum(fn($item) => $item->product->final_price * $item->quantity);
    }

    public function getCartCount(int $userId): int
    {
        return Cart::where('user_id', $userId)->sum('quantity') ?? 0;
    }
}
