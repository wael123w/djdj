@extends('layouts.app')
@section('title', __('Categories'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Categories') }}</h2>
    <div class="card mb-4">
        <div class="card-header">{{ __('Add Category') }}</div>
        <div class="card-body">
            <form action="{{ route('admin.categories.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row g-2">
                    <div class="col-md-3"><input type="text" name="name_ar" class="form-control" placeholder="{{ __('Name AR') }}" required></div>
                    <div class="col-md-3"><input type="text" name="name_en" class="form-control" placeholder="{{ __('Name EN') }}" required></div>
                    <div class="col-md-3"><input type="text" name="slug" class="form-control" placeholder="{{ __('Slug') }}" required></div>
                    <div class="col-md-3"><button type="submit" class="btn btn-primary-custom w-100">{{ __('Add') }}</button></div>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark"><tr><th>#</th><th>{{ __('Name') }}</th><th>{{ __('Slug') }}</th><th>{{ __('Products') }}</th><th>{{ __('Status') }}</th><th>{{ __('Actions') }}</th></tr></thead>
                    <tbody>
                        @foreach($categories as $c)
                        <tr>
                            <td>{{ $c->id }}</td>
                            <td>{{ $c->name }}</td>
                            <td>{{ $c->slug }}</td>
                            <td>{{ $c->products_count }}</td>
                            <td><span class="badge bg-{{ $c->is_active ? 'success' : 'danger' }}">{{ $c->is_active ? __('Active') : __('Inactive') }}</span></td>
                            <td>
                                <form action="{{ route('admin.categories.destroy', $c->id) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Are you sure?') }}')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
