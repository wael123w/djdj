<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\UserRepositoryInterface;

class UserController extends Controller
{
    public function __construct(private UserRepositoryInterface $userRepo) {}

    public function index()
    {
        $users = $this->userRepo->getAll(request()->only(['search', 'role']), 25);
        return view('admin.users.index', compact('users'));
    }

    public function show(int $id)
    {
        $user = $this->userRepo->findById($id);
        return view('admin.users.show', compact('user'));
    }

    public function update(int $id)
    {
        $user = $this->userRepo->findById($id);
        $data = request()->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id,
            'role' => 'required|in:admin,user,vendor',
            'is_active' => 'boolean',
            'balance' => 'nullable|numeric|min:0',
        ]);
        $this->userRepo->update($user, $data);
        return back()->with('success', __('User updated'));
    }
}
