@extends('layouts.app')
@section('title', __('Products'))
@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-lg-3">
            <div class="card mb-4">
                <div class="card-header bg-primary-custom text-white">{{ __('Filters') }}</div>
                <div class="card-body">
                    <form method="GET">
                        <div class="mb-3">
                            <label class="form-label">{{ __('Search') }}</label>
                            <input type="text" name="search" class="form-control" value="{{ request('search') }}">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">{{ __('Category') }}</label>
                            <select name="category_id" class="form-select">
                                <option value="">{{ __('All') }}</option>
                                @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">{{ __('Sort') }}</label>
                            <select name="sort" class="form-select">
                                <option value="">{{ __('Latest') }}</option>
                                <option value="price_asc" {{ request('sort') == 'price_asc' ? 'selected' : '' }}>{{ __('Price: Low to High') }}</option>
                                <option value="price_desc" {{ request('sort') == 'price_desc' ? 'selected' : '' }}>{{ __('Price: High to Low') }}</option>
                                <option value="popular" {{ request('sort') == 'popular' ? 'selected' : '' }}>{{ __('Most Popular') }}</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary-custom w-100">{{ __('Filter') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4>{{ __('Products') }} ({{ $products->total() }})</h4>
            </div>
            <div class="row g-4">
                @forelse($products as $product)
                <div class="col-6 col-md-4">
                    @include('components.product-card', ['product' => $product])
                </div>
                @empty
                <div class="col-12 text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <p class="mt-3 text-muted">{{ __('No products found') }}</p>
                </div>
                @endforelse
            </div>
            <div class="mt-4">
                {{ $products->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
