@extends('layouts.app')
@section('title', __('Add Product'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Add Product') }}</h2>
    <div class="card">
        <div class="card-body">
            <form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Name (AR)') }}</label>
                        <input type="text" name="name_ar" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Name (EN)') }}</label>
                        <input type="text" name="name_en" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Slug') }}</label>
                        <input type="text" name="slug" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Category') }}</label>
                        <select name="category_id" class="form-select" required>
                            @foreach($categories as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Price') }}</label>
                        <input type="number" step="0.01" name="price" class="form-control" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Sale Price') }}</label>
                        <input type="number" step="0.01" name="sale_price" class="form-control">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Cost Price') }}</label>
                        <input type="number" step="0.01" name="cost_price" class="form-control" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Stock') }}</label>
                        <input type="number" name="stock" class="form-control" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Min Qty') }}</label>
                        <input type="number" name="min_qty" class="form-control" value="1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Max Qty') }}</label>
                        <input type="number" name="max_qty" class="form-control" value="1" required>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">{{ __('Image') }}</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                    </div>
                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="is_active" class="form-check-input" id="is_active" value="1" checked>
                            <label class="form-check-label" for="is_active">{{ __('Active') }}</label>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" name="is_featured" class="form-check-input" id="is_featured" value="1">
                            <label class="form-check-label" for="is_featured">{{ __('Featured') }}</label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary-custom">{{ __('Save') }}</button>
                <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
            </form>
        </div>
    </div>
</div>
@endsection
