<?php

namespace App\Http\Controllers\Admin;

use App\Enums\OrderStatus;
use App\Http\Controllers\Controller;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\OrderService;

class OrderController extends Controller
{
    public function __construct(
        private OrderRepositoryInterface $orderRepo,
        private OrderService $orderService,
    ) {}

    public function index()
    {
        $orders = $this->orderRepo->getAll(request()->only(['status', 'search', 'date_from', 'date_to']), 25);
        return view('admin.orders.index', compact('orders'));
    }

    public function show(int $id)
    {
        $order = $this->orderRepo->findById($id);
        return view('admin.orders.show', compact('order'));
    }

    public function updateStatus(int $id)
    {
        $order = $this->orderRepo->findById($id);
        $status = OrderStatus::from(request('status'));
        $this->orderService->updateStatus($order, $status);
        return back()->with('success', __('Order status updated'));
    }
}
