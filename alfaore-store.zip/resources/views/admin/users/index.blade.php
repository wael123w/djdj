@extends('layouts.app')
@section('title', __('Users'))
@section('content')
<div class="container-fluid py-4">
    <h2 class="mb-4">{{ __('Users') }}</h2>
    <div class="card">
        <div class="card-body">
            <form method="GET" class="row g-2 mb-3">
                <div class="col-md-4"><input type="text" name="search" class="form-control" placeholder="{{ __('Search') }}" value="{{ request('search') }}"></div>
                <div class="col-md-2">
                    <select name="role" class="form-select">
                        <option value="">{{ __('All Roles') }}</option>
                        <option value="admin" {{ request('role') == 'admin' ? 'selected' : '' }}>{{ __('Admin') }}</option>
                        <option value="user" {{ request('role') == 'user' ? 'selected' : '' }}>{{ __('User') }}</option>
                        <option value="vendor" {{ request('role') == 'vendor' ? 'selected' : '' }}>{{ __('Vendor') }}</option>
                    </select>
                </div>
                <div class="col-md-2"><button type="submit" class="btn btn-primary-custom">{{ __('Filter') }}</button></div>
            </form>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark"><tr><th>#</th><th>{{ __('Name') }}</th><th>{{ __('Email') }}</th><th>{{ __('Role') }}</th><th>{{ __('Balance') }}</th><th>{{ __('Status') }}</th><th>{{ __('Actions') }}</th></tr></thead>
                    <tbody>
                        @foreach($users as $u)
                        <tr>
                            <td>{{ $u->id }}</td>
                            <td>{{ $u->name }}</td>
                            <td>{{ $u->email }}</td>
                            <td><span class="badge bg-{{ $u->role->value == 'admin' ? 'danger' : ($u->role->value == 'vendor' ? 'warning' : 'info') }}">{{ $u->role->label() }}</span></td>
                            <td>${{ number_format($u->balance, 2) }}</td>
                            <td><span class="badge bg-{{ $u->is_active ? 'success' : 'danger' }}">{{ $u->is_active ? __('Active') : __('Inactive') }}</span></td>
                            <td><a href="{{ route('admin.users.show', $u->id) }}" class="btn btn-sm btn-outline-primary">{{ __('View') }}</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $users->links() }}
        </div>
    </div>
</div>
@endsection
