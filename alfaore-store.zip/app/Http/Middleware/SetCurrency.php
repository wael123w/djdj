<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;

class SetCurrency
{
    public function handle(Request $request, Closure $next): Response
    {
        $currency = $request->session()->get('currency')
            ?? auth()->user()?->currency_code
            ?? config('app.currency', 'USD');

        Session::put('currency', $currency);
        return $next($request);
    }
}
