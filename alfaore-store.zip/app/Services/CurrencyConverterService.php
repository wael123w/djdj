<?php

namespace App\Services;

use App\Models\Currency;
use Illuminate\Support\Facades\Cache;

class CurrencyConverterService
{
    public function convert(float $amount, string $from, string $to): float
    {
        if ($from === $to) return $amount;
        $fromRate = $this->getRate($from);
        $toRate = $this->getRate($to);
        if (!$fromRate || !$toRate) return $amount;
        $baseAmount = $amount / $fromRate;
        return round($baseAmount * $toRate, 4);
    }

    public function format(float $amount, string $currencyCode): string
    {
        $currency = $this->getCurrency($currencyCode);
        $symbol = $currency?->symbol ?? '$';
        return $symbol . number_format($amount, 2);
    }

    private function getRate(string $code): ?float
    {
        return Cache::remember("currency.rate.{$code}", 3600, function () use ($code) {
            $currency = Currency::where('code', $code)->first();
            return $currency?->exchange_rate;
        });
    }

    private function getCurrency(string $code): ?Currency
    {
        return Cache::remember("currency.{$code}", 3600, function () use ($code) {
            return Currency::where('code', $code)->first();
        });
    }
}
